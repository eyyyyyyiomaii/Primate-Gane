# Game brief — PRIMATE: AFTER DARK

## Premise
You wake up at a remote coastal research outpost during a blackout. Three relay cores are offline. Restore them, avoid the Listener, and reach the evacuation gate.

## Play loop
Explore → find a relay landmark → use hand-push locomotion to cross the environment → restore the relay → the Listener becomes more threatening → restore all three → escape.

## Locomotion tuning
- Gorilla-style hand push-off using tracked controller positions and world collision.
- Horizontal speed cap: 7.2 m/s.
- Push gain: 23.0.
- Snap turn: 35 degrees, right thumbstick.
- No artificial smooth-stick translation by default.

## Map landmarks
- North Research Station: first relay and console.
- Signal Tower: elevated landmark and second relay.
- Flooded Service Tunnel: narrow route and third relay.
- Pine forest and broken perimeter ruins: traversal obstacles and navigation cues.
- Evacuation Gate: locked until all three relays are restored.

## Visual direction
Original dark teal / wet-concrete / moss palette. Textures in this prototype are generated locally for this project; no third-party game assets are copied.
