extends Node3D

# APRIMATE COLLECTION - original procedural VR prototype
# Seven playable themed variants share one movement/gameplay core.

const VARIANTS = [
    {"name":"APRIMATE: FURNACE", "zone":"Foundry", "accent":Color(1.0,0.27,0.055), "monster":"THE CINDER"},
    {"name":"BPRIMATE: FLOODLINE", "zone":"Floodworks", "accent":Color(0.08,0.65,0.82), "monster":"THE DREDGER"},
    {"name":"CPRIMATE: STATIC", "zone":"Signal Yard", "accent":Color(0.7,0.3,1.0), "monster":"THE RECEIVER"},
    {"name":"DPRIMATE: ROOTS", "zone":"Overgrowth", "accent":Color(0.3,0.8,0.24), "monster":"THE GRAFT"},
    {"name":"EPRIMATE: COLD STORAGE", "zone":"Cold Storage", "accent":Color(0.45,0.8,1.0), "monster":"THE HOLLOW"},
    {"name":"FPRIMATE: DEEP SHIFT", "zone":"Mine Level", "accent":Color(1.0,0.72,0.12), "monster":"THE DRILLER"},
    {"name":"GPRIMATE: LAST LIGHT", "zone":"Blacksite", "accent":Color(0.95,0.12,0.25), "monster":"THE WATCHER"}
]

var variant_index := 0
var xr_origin: XROrigin3D
var camera: XRCamera3D
var left_hand: XRController3D
var right_hand: XRController3D
var player: CharacterBody3D
var monster: Node3D
var hud: Label3D
var prompt: Label3D
var battery := 100.0
var relays := 0
var grabbed := false
var struggle := 0.0
var grab_timer := 0.0
var snap_ready := true
var previous_hands: Dictionary = {}
var monster_speed := 1.55
var is_xr := false
var start_position := Vector3(0, 0, 7)
var flashlight: SpotLight3D
var game_started := false
var menu_label: Label3D

func _ready() -> void:
    _setup_xr()
    _build_menu()

func _setup_xr() -> void:
    var interface := XRServer.find_interface("OpenXR")
    if interface and interface.is_initialized() == false:
        is_xr = interface.initialize()
        if is_xr:
            get_viewport().use_xr = true
    player = CharacterBody3D.new()
    player.name = "PlayerBody"
    player.position = start_position
    add_child(player)
    var capsule := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.28
    cap.height = 1.55
    capsule.shape = cap
    capsule.position.y = 0.78
    player.add_child(capsule)

    xr_origin = XROrigin3D.new()
    xr_origin.name = "XROrigin3D"
    player.add_child(xr_origin)
    camera = XRCamera3D.new()
    camera.position.y = 1.62
    xr_origin.add_child(camera)
    left_hand = XRController3D.new()
    left_hand.tracker = &"left_hand"
    left_hand.pose = &"default"
    xr_origin.add_child(left_hand)
    right_hand = XRController3D.new()
    right_hand.tracker = &"right_hand"
    right_hand.pose = &"default"
    xr_origin.add_child(right_hand)

    flashlight = SpotLight3D.new()
    flashlight.light_energy = 2.4
    flashlight.spot_range = 17.0
    flashlight.spot_angle = 43.0
    flashlight.position = Vector3(0.12, -0.12, -0.25)
    camera.add_child(flashlight)

func _build_menu() -> void:
    _clear_world()
    _make_environment(Color(0.018,0.014,0.02))
    var title := _label("APRIMATE COLLECTION", Vector3(0,2.4,-3.0), 0.42, Color(1,0.36,0.12))
    title.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    menu_label = _label("Choose a nightmare\n\nA  APRIMATE: FURNACE\nB  BPRIMATE: FLOODLINE\nC  CPRIMATE: STATIC\nD  DPRIMATE: ROOTS\nE  EPRIMATE: COLD STORAGE\nF  FPRIMATE: DEEP SHIFT\nG  GPRIMATE: LAST LIGHT\n\nPress A-G, then trigger / Enter to start", Vector3(0,1.25,-3.0), 0.16, Color(0.92,0.9,0.86))
    menu_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    _make_box(Vector3(0,-0.15,-3), Vector3(8,0.2,5), Color(0.07,0.065,0.075))
    prompt = _label("Selected: " + VARIANTS[variant_index].name, Vector3(0,0.5,-2.5), 0.19, VARIANTS[variant_index].accent)
    prompt.billboard = BaseMaterial3D.BILLBOARD_ENABLED

func _process(delta: float) -> void:
    if not game_started:
        _menu_input()
        return
    _snap_turn()
    battery = maxf(0.0, battery - delta * 0.12)
    if flashlight:
        flashlight.visible = battery > 0.0
    _update_monster(delta)
    _update_grab(delta)
    if hud:
        hud.text = "%s   |   RELAYS %d/3   |   BATTERY %d%%" % [VARIANTS[variant_index].name, relays, int(battery)]
    if Input.is_action_just_pressed("ui_cancel"):
        game_started = false
        _build_menu()

func _physics_process(delta: float) -> void:
    if not game_started or not player:
        return
    if is_xr:
        _hand_push(left_hand, "left", delta)
        _hand_push(right_hand, "right", delta)
    else:
        _desktop_move(delta)
    player.velocity.y -= 9.8 * delta
    player.move_and_slide()
    if player.global_position.y < -8:
        player.global_position = start_position
        player.velocity = Vector3.ZERO

func _menu_input() -> void:
    var keys = [KEY_A,KEY_B,KEY_C,KEY_D,KEY_E,KEY_F,KEY_G]
    for i in range(keys.size()):
        if Input.is_key_pressed(keys[i]):
            variant_index = i
            if prompt:
                prompt.text = "Selected: " + VARIANTS[i].name
                prompt.modulate = VARIANTS[i].accent
    if Input.is_key_pressed(KEY_ENTER) or Input.is_key_pressed(KEY_SPACE):
        _start_game()
    if is_xr and right_hand and right_hand.is_button_pressed("trigger"):
        _start_game()

func _start_game() -> void:
    game_started = true
    relays = 0
    battery = 100.0
    grabbed = false
    struggle = 0.0
    player.global_position = start_position
    player.velocity = Vector3.ZERO
    _clear_world()
    _build_level()
    _spawn_monster()
    hud = _label("", Vector3(0,2.0,-2.2), 0.12, Color(1,0.9,0.72))
    hud.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    camera.add_child(hud)
    prompt = _label("Find 3 relay switches. Keep moving.", Vector3(0,1.75,-2.0), 0.11, Color(1,0.5,0.18))
    prompt.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    camera.add_child(prompt)

func _build_level() -> void:
    var v = VARIANTS[variant_index]
    _make_environment(Color(0.012,0.012,0.018))
    var floor_mat := _mat(Color(0.20,0.16,0.13), 0.85)
    _make_box(Vector3(0,-0.25,0), Vector3(44,0.5,48), floor_mat.albedo_color, floor_mat)
    # Large industrial halls and connected corridors
    _make_box(Vector3(0,3,-13), Vector3(44,6,0.5), Color(0.20,0.105,0.065))
    _make_box(Vector3(-21,3,0), Vector3(0.5,6,48), Color(0.19,0.12,0.085))
    _make_box(Vector3(21,3,0), Vector3(0.5,6,48), Color(0.19,0.12,0.085))
    _make_box(Vector3(0,3,23), Vector3(44,6,0.5), Color(0.17,0.10,0.07))
    # maze partitions
    for p in [Vector3(-10,1.6,-5),Vector3(-2,1.6,-1),Vector3(8,1.6,-7),Vector3(13,1.6,4),Vector3(2,1.6,9),Vector3(-9,1.6,13),Vector3(-15,1.6,4)]:
        _make_box(p, Vector3(0.45,3.2,8), Color(0.29,0.15,0.09))
    for p in [Vector3(-6,1.3,-10),Vector3(5,1.3,-3),Vector3(15,1.3,-10),Vector3(9,1.3,11),Vector3(-3,1.3,17)]:
        _make_box(p, Vector3(7,2.6,0.45), Color(0.34,0.18,0.10))
    # raised platforms and pipes
    for i in range(8):
        var x = -16.0 + float(i % 4) * 10.0
        var z = -8.0 + float(i / 4) * 19.0
        _make_box(Vector3(x,0.7,z), Vector3(3.2,0.45,3.2), Color(0.31,0.25,0.20))
        _make_cylinder(Vector3(x+1.5,2.4,z), 0.22, 4.5, v.accent)
    for i in range(5):
        _make_cylinder(Vector3(-14 + i*7,4.8,-1),0.16,18.0,Color(0.48,0.23,0.11),Vector3(0,0,PI/2))
    # lights
    for p in [Vector3(-14,4,-9),Vector3(0,4,-9),Vector3(14,4,-9),Vector3(-14,4,8),Vector3(0,4,8),Vector3(14,4,8)]:
        var light := OmniLight3D.new()
        light.position = p
        light.light_color = v.accent
        light.light_energy = 0.65
        light.omni_range = 10
        add_child(light)
    # relay stations
    for i in range(3):
        var z = -9.0 + i*10.0
        var x = [-16.0, 15.0, 0.0][i]
        _make_box(Vector3(x,0.75,z),Vector3(1.0,1.5,0.8),Color(0.10,0.12,0.13))
        var relay := Area3D.new()
        relay.name = "Relay_%d" % i
        relay.position = Vector3(x,1.0,z)
        var shape := CollisionShape3D.new()
        var sphere := SphereShape3D.new()
        sphere.radius = 1.1
        shape.shape = sphere
        relay.add_child(shape)
        relay.body_entered.connect(_on_relay_entered.bind(relay))
        add_child(relay)
        _label("RELAY %d" % (i+1), Vector3(x,2.0,z), 0.18, v.accent)
    _label(v.zone.to_upper(), Vector3(0,5.3,-12), 0.34, v.accent)
    _make_box(Vector3(0,1.5,21),Vector3(5,3,0.5),Color(0.12,0.14,0.12))
    _label("EXIT",Vector3(0,3.5,20.5),0.3,Color(0.4,1,0.45))

func _spawn_monster() -> void:
    monster = Node3D.new()
    monster.name = VARIANTS[variant_index].monster
    monster.position = Vector3(0,0,-10)
    add_child(monster)
    var accent: Color = VARIANTS[variant_index].accent
    _make_sphere(monster,Vector3(0,1.25,0),Vector3(0.8,1.15,0.55),Color(0.035,0.025,0.03))
    _make_sphere(monster,Vector3(0,2.45,-0.05),Vector3(0.85,0.8,0.7),Color(0.018,0.014,0.02))
    # asymmetrical crown / horns
    for side in [-1,1]:
        _make_cylinder(Vector3(side*0.55,3.15,-0.05),0.16,0.9,Color(0.07,0.04,0.04),Vector3(0,0,side*0.42), monster)
        _make_sphere(monster,Vector3(side*0.31,2.55,-0.66),Vector3(0.18,0.13,0.1),accent)
        _make_sphere(monster,Vector3(side*0.31,2.55,-0.76),Vector3(0.07,0.07,0.04),Color(1.0,0.82,0.58))
        # long arms
        _make_cylinder(Vector3(side*0.95,1.25,-0.05),0.22,1.9,Color(0.025,0.02,0.025),Vector3(0,0,side*0.7), monster)
        _make_sphere(monster,Vector3(side*1.35,0.25,-0.1),Vector3(0.34,0.27,0.3),Color(0.025,0.02,0.025))
    _label(VARIANTS[variant_index].monster, Vector3(0,3.65,0),0.17,accent)

func _update_monster(delta: float) -> void:
    if not is_instance_valid(monster):
        return
    var target = player.global_position
    target.y = monster.global_position.y
    var distance = monster.global_position.distance_to(target)
    var speed = monster_speed + float(relays)*0.28
    if distance > 1.5:
        monster.global_position = monster.global_position.move_toward(target, speed*delta)
        monster.look_at(Vector3(target.x,monster.global_position.y,target.z),Vector3.UP)
    if distance < 1.35 and not grabbed:
        grabbed = true
        grab_timer = 0.0
        struggle = 0.0
        if prompt:
            prompt.text = "CAUGHT! MOVE BOTH HANDS TO BREAK FREE!"

func _update_grab(delta: float) -> void:
    if not grabbed:
        return
    grab_timer += delta
    if is_xr:
        var l = _hand_speed(left_hand, "left", delta)
        var r = _hand_speed(right_hand, "right", delta)
        struggle += (l+r)*delta
    else:
        if Input.is_action_pressed("ui_left") or Input.is_action_pressed("ui_right") or Input.is_action_pressed("ui_up") or Input.is_action_pressed("ui_down"):
            struggle += delta*2.5
    player.velocity = Vector3.ZERO
    if struggle > 2.4:
        grabbed = false
        monster.global_position += (monster.global_position-player.global_position).normalized()*5.0
        if prompt: prompt.text = "ESCAPED! KEEP MOVING!"
    elif grab_timer > 4.5:
        grabbed = false
        player.global_position = start_position
        monster.global_position = Vector3(0,0,-10)
        if prompt: prompt.text = "You escaped the capture. Try another route."

func _hand_push(hand: XRController3D, key: String, delta: float) -> void:
    if not hand or not hand.get_is_active():
        return
    var current = hand.global_position
    if not previous_hands.has(key):
        previous_hands[key] = current
        return
    var old: Vector3 = previous_hands[key]
    var motion = current-old
    previous_hands[key] = current
    if motion.length() < 0.002 or motion.length() > 0.35:
        return
    var sphere := SphereShape3D.new()
    sphere.radius = 0.13
    var query := PhysicsShapeQueryParameters3D.new()
    query.shape = sphere
    query.transform = Transform3D(Basis(), old)
    query.motion = motion
    query.exclude = [player.get_rid()]
    query.collide_with_bodies = true
    var hits = get_world_3d().direct_space_state.cast_motion(query)
    if hits.size() > 0 and hits[0] < 0.98:
        var push = -motion / maxf(delta,0.001)
        push.y = maxf(push.y,0.0)
        player.velocity += push*0.9
        player.velocity = player.velocity.limit_length(7.2)

func _hand_speed(hand: XRController3D, key: String, delta: float) -> float:
    if not hand or not hand.get_is_active():
        return 0.0
    var current = hand.global_position
    if not previous_hands.has("struggle_"+key):
        previous_hands["struggle_"+key] = current
        return 0.0
    var old: Vector3 = previous_hands["struggle_"+key]
    previous_hands["struggle_"+key] = current
    return old.distance_to(current)/maxf(delta,0.001)

func _desktop_move(delta: float) -> void:
    var input_dir = Vector2.ZERO
    input_dir.x = Input.get_axis("ui_left","ui_right")
    input_dir.y = Input.get_axis("ui_up","ui_down")
    var dir = Vector3(input_dir.x,0,input_dir.y).rotated(Vector3.UP,camera.global_rotation.y)
    if dir.length() > 0:
        player.velocity.x = dir.normalized().x*4.2
        player.velocity.z = dir.normalized().z*4.2
    else:
        player.velocity.x = move_toward(player.velocity.x,0,12*delta)
        player.velocity.z = move_toward(player.velocity.z,0,12*delta)

func _snap_turn() -> void:
    var left = Input.is_action_just_pressed("snap_left")
    var right = Input.is_action_just_pressed("snap_right")
    if is_xr and right_hand and right_hand.get_is_active():
        left = left or right_hand.is_button_pressed("grip_click") and false
        right = right or right_hand.is_button_pressed("ax_button") and false
    if left:
        xr_origin.rotate_y(deg_to_rad(35))
    elif right:
        xr_origin.rotate_y(deg_to_rad(-35))

func _on_relay_entered(body: Node3D, relay: Area3D) -> void:
    if body != player or relay.get_meta("used",false):
        return
    relay.set_meta("used",true)
    relays += 1
    relay.monitoring = false
    if prompt:
        prompt.text = "RELAY RESTORED: %d/3" % relays
    if relays == 3 and prompt:
        prompt.text = "ALL RELAYS ONLINE. REACH THE EXIT!"

func _clear_world() -> void:
    for child in get_children():
        if child != player:
            child.queue_free()
    if player:
        for child in xr_origin.get_children():
            if child != camera and child != left_hand and child != right_hand:
                child.queue_free()

func _make_environment(color: Color) -> void:
    var env := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = color
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.32,0.25,0.22)
    e.ambient_light_energy = 0.65
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.environment = e
    add_child(env)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55,-25,0)
    sun.light_energy = 0.35
    add_child(sun)

func _mat(color: Color, rough: float=0.8) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = rough
    return m

func _make_box(pos: Vector3, size: Vector3, color: Color, material: Material=null) -> MeshInstance3D:
    var mesh := MeshInstance3D.new()
    var b := BoxMesh.new()
    b.size = size
    mesh.mesh = b
    mesh.position = pos
    mesh.material_override = material if material else _mat(color)
    var body := StaticBody3D.new()
    body.position = pos
    var col := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    col.shape = shape
    body.add_child(col)
    add_child(body)
    add_child(mesh)
    return mesh

func _make_cylinder(pos: Vector3, radius: float, height: float, color: Color, rot: Vector3=Vector3.ZERO, parent: Node3D=null) -> MeshInstance3D:
    var mesh := MeshInstance3D.new()
    var c := CylinderMesh.new()
    c.top_radius = radius
    c.bottom_radius = radius
    c.height = height
    mesh.mesh = c
    mesh.position = pos
    mesh.rotation = rot
    mesh.material_override = _mat(color)
    if parent:
        parent.add_child(mesh)
    else:
        add_child(mesh)
    return mesh

func _make_sphere(parent: Node3D, pos: Vector3, scale_v: Vector3, color: Color) -> MeshInstance3D:
    var mesh := MeshInstance3D.new()
    var s := SphereMesh.new()
    s.radius = 0.5
    s.height = 1.0
    mesh.mesh = s
    mesh.position = pos
    mesh.scale = scale_v
    mesh.material_override = _mat(color)
    parent.add_child(mesh)
    return mesh

func _label(text_value: String, pos: Vector3, size: float, color: Color) -> Label3D:
    var label := Label3D.new()
    label.text = text_value
    label.position = pos
    label.font_size = int(64*size)
    label.modulate = color
    label.outline_size = 8
    add_child(label)
    return label
