extends Node3D

# PRIMATE: AFTER DARK — procedural Quest 3S prototype.
# Offline demo player actions are local placeholders; real multiplayer moderation
# requires a trusted server and authenticated player IDs.

@export var snap_turn_degrees := 35.0
@export var desktop_speed := 4.0
@export var hammer_reach := 1.65

var xr_enabled := false
var xr_origin: XROrigin3D
var xr_camera: XRCamera3D
var left_hand: XRController3D
var right_hand: XRController3D
var desktop_camera: Camera3D
var player_root: CharacterBody3D
var avatar: Node3D
var wrist_device: Node3D
var wrist_front: MeshInstance3D
var wrist_back: MeshInstance3D
var hammer_root: Node3D
var hammer_head: MeshInstance3D
var hammer_mode := 0 # 0 yellow, 1 red, 2 inverted blue
var hammer_cooldown := 0.0
var snap_cooldown := 0.0
var credits := 0
var relays_found := 0
var companion_owned := false
var companion_node: Node3D
var companion_in_flight := false
var active_monster: Node3D
var player_rows: Array[Dictionary] = []
var muted_players: Dictionary = {}
var banned_players: Dictionary = {}
var status_label: Label3D
var admin_subviewport: SubViewport
var admin_root: Control
var admin_open := true
var desktop_yaw := 0.0
var desktop_pitch := -0.12
var previous_left_hand := Vector3.ZERO
var previous_right_hand := Vector3.ZERO
var have_hand_samples := false
var flight_enabled := false
var noclip_enabled := false
var last_x := false
var last_y := false
var last_trigger := false

const PURPLE := Color(0.42, 0.08, 0.95)
const NEON_PURPLE := Color(0.72, 0.16, 1.0)
const RED := Color(1.0, 0.025, 0.035)
const BLUE := Color(0.08, 0.22, 1.0)
const GOLD := Color(1.0, 0.72, 0.05)

func _ready() -> void:
    _setup_input()
    _build_world()
    _build_player()
    _build_avatar()
    _build_admin_panel()
    _build_hammer()
    _build_hammers_display()
    _build_map_objects()
    _build_monster()
    _build_companion_shop()
    _setup_openxr()
    _set_status("PRIMATE: AFTER DARK • Quest 3S prototype")

func _setup_input() -> void:
    _add_key_action("move_forward", KEY_W)
    _add_key_action("move_back", KEY_S)
    _add_key_action("move_left", KEY_A)
    _add_key_action("move_right", KEY_D)
    _add_key_action("turn_left", KEY_Q)
    _add_key_action("turn_right", KEY_E)
    _add_key_action("interact", KEY_ENTER)
    _add_key_action("hammer_swing", KEY_SPACE)
    _add_key_action("toggle_admin", KEY_TAB)
    _add_key_action("hammer_red", KEY_X)
    _add_key_action("hammer_inverted", KEY_Y)

func _add_key_action(action: String, keycode: int) -> void:
    if not InputMap.has_action(action):
        InputMap.add_action(action)
    var ev := InputEventKey.new()
    ev.physical_keycode = keycode
    InputMap.action_add_event(action, ev)

func _mat(color: Color, emission: Color = Color.BLACK, metallic: float = 0.0, rough: float = 0.55) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.metallic = metallic
    m.roughness = rough
    if emission != Color.BLACK:
        m.emission_enabled = true
        m.emission = emission
        m.emission_energy_multiplier = 1.4
    return m

func _mesh_box(parent: Node3D, size: Vector3, pos: Vector3, material: Material, name: String = "Box") -> MeshInstance3D:
    var n := MeshInstance3D.new()
    n.name = name
    var mesh := BoxMesh.new()
    mesh.size = size
    n.mesh = mesh
    n.position = pos
    n.material_override = material
    parent.add_child(n)
    return n

func _mesh_sphere(parent: Node3D, radius: float, pos: Vector3, material: Material, name: String = "Orb") -> MeshInstance3D:
    var n := MeshInstance3D.new()
    n.name = name
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    n.mesh = mesh
    n.position = pos
    n.material_override = material
    parent.add_child(n)
    return n

func _build_world() -> void:
    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.012, 0.002, 0.055)
    sky_mat.sky_horizon_color = Color(0.16, 0.015, 0.32)
    sky_mat.ground_bottom_color = Color(0.008, 0.004, 0.02)
    sky_mat.ground_horizon_color = Color(0.045, 0.008, 0.09)
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.34, 0.19, 0.58)
    env.ambient_light_energy = 0.65
    env_node.environment = env
    add_child(env_node)
    var key := DirectionalLight3D.new()
    key.rotation_degrees = Vector3(-48, -28, 0)
    key.light_color = Color(0.72, 0.55, 1.0)
    key.light_energy = 0.85
    add_child(key)
    _mesh_box(self, Vector3(90, 0.5, 90), Vector3(0, -0.35, 0), _mat(Color(0.035, 0.025, 0.065), Color(0.035, 0.005, 0.08), 0.45, 0.35), "CosmicGround")
    var ground_body := StaticBody3D.new()
    ground_body.position = Vector3(0, -0.35, 0)
    var ground_collision := CollisionShape3D.new()
    var ground_shape := BoxShape3D.new()
    ground_shape.size = Vector3(90, 0.5, 90)
    ground_collision.shape = ground_shape
    ground_body.add_child(ground_collision)
    add_child(ground_body)
    # Floating rock silhouettes and colored nebula-like light sources.
    for i in range(34):
        var a := float(i) * 2.399
        var r := 13.0 + float(i % 7) * 2.2
        var rock := _mesh_sphere(self, 0.45 + float(i % 4) * 0.18, Vector3(cos(a) * r, 2.0 + float(i % 5) * 1.4, sin(a) * r), _mat(Color(0.08, 0.045, 0.13), Color(0.12, 0.015, 0.2), 0.15, 0.9), "FloatingAsteroid")
        rock.scale = Vector3(1.0, 0.72, 1.15)
    for p in [Vector3(-8, 3, -10), Vector3(11, 5, -12), Vector3(0, 7, 16)]:
        var light := OmniLight3D.new()
        light.position = p
        light.light_color = Color(0.55, 0.08, 1.0)
        light.light_energy = 2.0
        light.omni_range = 18.0
        add_child(light)

func _build_player() -> void:
    player_root = CharacterBody3D.new()
    player_root.name = "PlayerRig"
    player_root.position = Vector3(0, 0, 6)
    var player_collision := CollisionShape3D.new()
    var player_capsule := CapsuleShape3D.new()
    player_capsule.radius = 0.28
    player_capsule.height = 1.55
    player_collision.shape = player_capsule
    player_collision.position.y = 0.78
    player_root.add_child(player_collision)
    add_child(player_root)
    xr_origin = XROrigin3D.new()
    player_root.add_child(xr_origin)
    xr_camera = XRCamera3D.new()
    xr_camera.position.y = 1.58
    xr_origin.add_child(xr_camera)
    left_hand = XRController3D.new()
    left_hand.name = "LeftHand"
    left_hand.tracker = StringName("left_hand")
    left_hand.pose = &"default"
    xr_origin.add_child(left_hand)
    right_hand = XRController3D.new()
    right_hand.name = "RightHand"
    right_hand.tracker = StringName("right_hand")
    right_hand.pose = &"default"
    xr_origin.add_child(right_hand)
    desktop_camera = Camera3D.new()
    desktop_camera.position = Vector3(0, 2.8, 11)
    desktop_camera.rotation_degrees = Vector3(-8, 0, 0)
    desktop_camera.current = true
    add_child(desktop_camera)

func _setup_openxr() -> void:
    var iface := XRServer.find_interface("OpenXR")
    if iface and (iface.is_initialized() or iface.initialize()):
        xr_enabled = true
        get_viewport().use_xr = true
        desktop_camera.current = false
        _set_status("OPENXR ACTIVE • QUEST MODE")
    else:
        xr_enabled = false
        _set_status("DESKTOP PREVIEW • WASD / TAB / X / Y / SPACE")

func _build_avatar() -> void:
    avatar = Node3D.new()
    avatar.name = "Chuvapchichi11_Avatar"
    avatar.position = Vector3(0, 0, 1.8)
    add_child(avatar)
    var red := _mat(Color(0.48, 0.018, 0.025), Color(0.12, 0.002, 0.005), 0.05, 0.82)
    var face := _mat(Color(0.68, 0.66, 0.61), Color.BLACK, 0, 0.9)
    var dark := _mat(Color(0.012, 0.008, 0.018))
    _mesh_sphere(avatar, 0.57, Vector3(0, 1.5, 0), red, "GorillaTorso")
    _mesh_sphere(avatar, 0.43, Vector3(0, 2.22, -0.03), red, "GorillaHead")
    _mesh_sphere(avatar, 0.31, Vector3(0, 2.17, -0.39), face, "FaceMask")
    _mesh_sphere(avatar, 0.095, Vector3(-0.15, 2.25, -0.66), dark, "LeftEye")
    _mesh_sphere(avatar, 0.095, Vector3(0.15, 2.25, -0.66), dark, "RightEye")
    _mesh_sphere(avatar, 0.11, Vector3(0, 2.02, -0.66), dark, "Nose")
    _mesh_sphere(avatar, 0.36, Vector3(0, 1.52, -0.42), face, "ChestPatch")
    for side in [-1.0, 1.0]:
        var arm := _mesh_sphere(avatar, 0.25, Vector3(side * 0.78, 1.45, -0.05), red, "Arm")
        arm.scale = Vector3(1.0, 1.8, 1.0)
        var hand := _mesh_sphere(avatar, 0.25, Vector3(side * 0.94, 0.48, -0.16), red, "Hand")
        hand.scale = Vector3(1.4, 0.75, 1.2)
        var leg := _mesh_sphere(avatar, 0.25, Vector3(side * 0.28, 0.48, 0.18), red, "Leg")
        leg.scale = Vector3(1.0, 1.6, 1.0)
    var name_tag := Label3D.new()
    name_tag.text = "Chuvapchichi11"
    name_tag.font_size = 34
    name_tag.position = Vector3(0, 3.0, 0)
    name_tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    name_tag.modulate = Color(1, 0.86, 1)
    avatar.add_child(name_tag)

func _build_admin_panel() -> void:
    wrist_device = Node3D.new()
    wrist_device.name = "WristAdminDevice"
    # In VR it follows the left wrist. Desktop preview keeps it visible in front of the avatar.
    left_hand.add_child(wrist_device)
    wrist_device.position = Vector3(0, 0.02, -0.16)
    wrist_device.rotation_degrees = Vector3(-68, 0, 0)
    _mesh_box(wrist_device, Vector3(0.31, 0.045, 0.22), Vector3(0, 0, 0), _mat(Color(0.025, 0.012, 0.055), Color(0.35, 0.025, 0.8), 0.7, 0.25), "WristStrap")
    var bezel := _mesh_box(wrist_device, Vector3(0.30, 0.035, 0.205), Vector3(0, 0.035, 0), _mat(Color(0.055, 0.018, 0.09), Color(0.42, 0.04, 1.0), 0.7, 0.2), "PanelBezel")
    wrist_front = MeshInstance3D.new()
    var front_mesh := BoxMesh.new()
    front_mesh.size = Vector3(0.275, 0.012, 0.18)
    wrist_front.mesh = front_mesh
    wrist_front.position = Vector3(0, 0.057, 0)
    wrist_device.add_child(wrist_front)
    _create_admin_viewport()
    var front_material := StandardMaterial3D.new()
    front_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    front_material.albedo_texture = admin_subviewport.get_texture()
    wrist_front.material_override = front_material
    wrist_back = MeshInstance3D.new()
    var back_mesh := BoxMesh.new()
    back_mesh.size = Vector3(0.275, 0.012, 0.18)
    wrist_back.mesh = back_mesh
    wrist_back.position = Vector3(0, -0.026, 0)
    wrist_back.rotation_degrees.x = 180
    wrist_device.add_child(wrist_back)
    var image := Image.load_from_file("res://assets/panel_back_reference.jpg")
    if image:
        var tex := ImageTexture.create_from_image(image)
        var back_mat := StandardMaterial3D.new()
        back_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        back_mat.albedo_texture = tex
        wrist_back.material_override = back_mat
    else:
        wrist_back.material_override = _mat(Color(0.9, 0.12, 0.12), Color(0.3, 0.01, 0.01))
    # Desktop-only wrist display so the device is still visible without a headset/controller.
    var desktop_copy := wrist_device.duplicate()
    desktop_copy.name = "DesktopWristAdminPreview"
    desktop_copy.position = Vector3(-1.0, 1.35, 0.4)
    desktop_copy.rotation_degrees = Vector3(-18, 12, 0)
    avatar.add_child(desktop_copy)

func _create_admin_viewport() -> void:
    admin_subviewport = SubViewport.new()
    admin_subviewport.name = "AdminPanelViewport"
    admin_subviewport.size = Vector2i(1024, 640)
    admin_subviewport.transparent_bg = false
    admin_subviewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    add_child(admin_subviewport)
    admin_root = Control.new()
    admin_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    admin_subviewport.add_child(admin_root)
    var bg := ColorRect.new()
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.color = Color(0.012, 0.004, 0.035, 1)
    admin_root.add_child(bg)
    var stars := Control.new()
    stars.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    admin_root.add_child(stars)
    for i in range(95):
        var star := ColorRect.new()
        var px := float((i * 137 + 41) % 1000)
        var py := float((i * 223 + 17) % 620)
        star.position = Vector2(px, py)
        star.size = Vector2(2.0 + float(i % 3), 2.0 + float(i % 3))
        star.color = Color(0.55 + float(i % 4) * 0.1, 0.35, 1.0, 0.85)
        stars.add_child(star)
    var title := Label.new()
    title.text = "♛  ADMIN PANEL"
    title.position = Vector2(24, 10)
    title.add_theme_font_size_override("font_size", 44)
    title.add_theme_color_override("font_color", Color(0.96, 0.86, 1))
    admin_root.add_child(title)
    var left := VBoxContainer.new()
    left.position = Vector2(20, 75)
    left.size = Vector2(490, 530)
    left.add_theme_constant_override("separation", 8)
    admin_root.add_child(left)
    _add_admin_button(left, "▣  Give Resources  +100 scrap", func(): _give_resources())
    _add_admin_button(left, "✦  Fly  [toggle]", func(): _toggle_flight())
    _add_admin_button(left, "◉  Speed Boost  [toggle]", func(): _toggle_speed())
    _add_admin_button(left, "❄  No Clip  [toggle]", func(): _toggle_noclip())
    _add_admin_button(left, "♟  Monkey List  ▸", func(): _show_player_list())
    _add_admin_button(left, "⇧  Teleport to Spawn", func(): _teleport_spawn())
    _add_admin_button(left, "★  Unlock Cosmetics", func(): _set_status("Cosmetic preview unlocked for this local session"))
    var right := VBoxContainer.new()
    right.position = Vector2(530, 80)
    right.size = Vector2(470, 520)
    right.add_theme_constant_override("separation", 5)
    admin_root.add_child(right)
    var list_title := Label.new()
    list_title.text = "MONKEY LIST • LOCAL DEMO"
    list_title.add_theme_font_size_override("font_size", 27)
    list_title.add_theme_color_override("font_color", Color(1, 0.25, 0.35))
    right.add_child(list_title)
    player_rows = [
        {"name":"Chuvapchichi11", "id":"local_owner", "owner":true},
        {"name":"SigmaMonke", "id":"bot_sigma", "owner":false},
        {"name":"monkey_228", "id":"bot_228", "owner":false}
    ]
    for row in player_rows:
        var line := HBoxContainer.new()
        right.add_child(line)
        var player_name := Label.new()
        player_name.text = str(row.name)
        player_name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        player_name.add_theme_font_size_override("font_size", 20)
        line.add_child(player_name)
        _small_action_button(line, "TP", Color(0.05, 0.35, 1), func(): _teleport_to_player(str(row.id)))
        _small_action_button(line, "BAN", Color(0.85, 0.04, 0.07), func(): _ban_player(str(row.id)))
        _small_action_button(line, "MUTE", Color(0.23, 0.23, 0.3), func(): _mute_player(str(row.id)))
    var note := Label.new()
    note.text = "Made by Chuvapchichi <3"
    note.position = Vector2(535, 570)
    note.add_theme_font_size_override("font_size", 23)
    note.add_theme_color_override("font_color", Color(1, 0.78, 1))
    admin_root.add_child(note)

func _add_admin_button(parent: VBoxContainer, caption: String, callback: Callable) -> void:
    var b := Button.new()
    b.text = caption
    b.custom_minimum_size = Vector2(470, 58)
    b.add_theme_font_size_override("font_size", 25)
    b.add_theme_color_override("font_color", Color(0.96, 0.91, 1))
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.045, 0.018, 0.075, 0.94)
    normal.border_width_left = 3
    normal.border_color = Color(0.55, 0.12, 0.95)
    normal.corner_radius_top_left = 8
    normal.corner_radius_top_right = 8
    normal.corner_radius_bottom_left = 8
    normal.corner_radius_bottom_right = 8
    b.add_theme_stylebox_override("normal", normal)
    b.pressed.connect(callback)
    parent.add_child(b)

func _small_action_button(parent: HBoxContainer, caption: String, color: Color, callback: Callable) -> void:
    var b := Button.new()
    b.text = caption
    b.custom_minimum_size = Vector2(68, 38)
    b.add_theme_font_size_override("font_size", 17)
    var style := StyleBoxFlat.new()
    style.bg_color = color
    style.corner_radius_top_left = 6
    style.corner_radius_top_right = 6
    style.corner_radius_bottom_left = 6
    style.corner_radius_bottom_right = 6
    b.add_theme_stylebox_override("normal", style)
    b.pressed.connect(callback)
    parent.add_child(b)

func _build_hammer() -> void:
    hammer_root = Node3D.new()
    hammer_root.name = "VRStopHammer"
    right_hand.add_child(hammer_root)
    hammer_root.position = Vector3(0, -0.03, -0.34)
    hammer_root.rotation_degrees = Vector3(90, 0, 0)
    _make_hammer_model(hammer_root, 0)

func _make_hammer_model(parent: Node3D, mode: int) -> void:
    for child in parent.get_children():
        child.queue_free()
    var accent := GOLD if mode == 0 else (RED if mode == 1 else BLUE)
    var glow := Color(1, 0.55, 0.02) if mode == 0 else (Color(1, 0.01, 0.015) if mode == 1 else Color(0.05, 0.18, 1))
    var dark := _mat(Color(0.018, 0.012, 0.025), Color(0.05, 0.01, 0.08), 0.7, 0.25)
    var bright := _mat(accent, glow, 0.45, 0.24)
    _mesh_box(parent, Vector3(0.105, 0.105, 0.72), Vector3(0, 0, 0.24), dark, "Handle")
    _mesh_box(parent, Vector3(0.20, 0.16, 0.09), Vector3(0, 0, 0.58), dark, "Pommel")
    _mesh_box(parent, Vector3(0.62, 0.40, 0.36), Vector3(0, 0.04, -0.19), bright, "HammerHead")
    _mesh_box(parent, Vector3(0.66, 0.055, 0.39), Vector3(0, 0.26, -0.19), dark, "TopRidge")
    _mesh_box(parent, Vector3(0.68, 0.045, 0.40), Vector3(0, -0.18, -0.19), bright, "LowerRim")
    var face := _mesh_box(parent, Vector3(0.48, 0.25, 0.012), Vector3(0, 0.04, -0.375), _mat(Color(0.015, 0.01, 0.02), Color(0.01, 0.01, 0.02)), "STOPFace")
    var label := Label3D.new()
    label.text = "STOP"
    label.font_size = 54
    label.position = Vector3(0, 0.035, -0.386)
    label.rotation_degrees = Vector3(0, 0, 0)
    label.modulate = Color(1, 1, 1)
    parent.add_child(label)
    var glow_edge := _mesh_box(parent, Vector3(0.72, 0.035, 0.44), Vector3(0, 0.245, -0.19), bright, "GlowTrim")
    hammer_head = parent.get_node_or_null("HammerHead") as MeshInstance3D

func _build_hammers_display() -> void:
    var stand := Node3D.new()
    stand.position = Vector3(3.0, 0.0, -1.5)
    add_child(stand)
    var colors := [GOLD, RED, BLUE]
    for i in range(3):
        var h := Node3D.new()
        h.position = Vector3((i - 1) * 1.5, 1.5, 0)
        stand.add_child(h)
        _make_hammer_model(h, i)
        h.rotation_degrees = Vector3(0, 0, -7)
        var pl := OmniLight3D.new()
        pl.position = Vector3(0, 0.6, -0.4)
        pl.light_color = colors[i]
        pl.light_energy = 1.0
        pl.omni_range = 3.2
        h.add_child(pl)

func _build_map_objects() -> void:
    # Simple playable clearing and forest silhouettes retained from the earlier prototype.
    var floor_mat := _mat(Color(0.07, 0.045, 0.09), Color(0.035, 0.005, 0.06), 0.25, 0.8)
    for x in range(-24, 25, 4):
        for z in range(-24, 25, 4):
            if abs(x) < 6 and abs(z) < 8:
                continue
            var trunk := _mesh_box(self, Vector3(0.28, 2.3, 0.28), Vector3(x, 0.8, z), _mat(Color(0.12, 0.055, 0.04)), "TreeTrunk")
            var crown := _mesh_sphere(self, 1.0, Vector3(x, 2.45, z), _mat(Color(0.045, 0.11, 0.075), Color(0.015, 0.05, 0.03)), "TreeCrown")
            crown.scale = Vector3(1.0, 1.35, 1.0)
    _mesh_box(self, Vector3(7, 2.8, 0.35), Vector3(0, 1.4, -7), _mat(Color(0.12, 0.13, 0.16)), "ResearchStation")
    _mesh_box(self, Vector3(5, 0.2, 5), Vector3(0, 0.05, -4), _mat(Color(0.16, 0.14, 0.2), Color(0.04, 0.01, 0.1)), "StationPad")
    for p in [Vector3(-3, 0.8, -3), Vector3(4, 0.8, -6), Vector3(14, 0.8, 12)]:
        _spawn_relay(p)

func _spawn_relay(pos: Vector3) -> void:
    var relay_node := Area3D.new()
    relay_node.position = pos
    relay_node.add_to_group("relay")
    var cs := CollisionShape3D.new()
    var shape := SphereShape3D.new()
    shape.radius = 1.0
    cs.shape = shape
    relay_node.add_child(cs)
    var core := _mesh_sphere(relay_node, 0.22, Vector3.ZERO, _mat(Color(0.1, 0.7, 1), Color(0.05, 0.5, 1)), "RelayCore")
    var ring := _mesh_box(relay_node, Vector3(0.7, 0.06, 0.7), Vector3.ZERO, _mat(Color(0.05, 0.35, 0.8), Color(0.03, 0.25, 1)), "RelayRing")
    relay_node.body_entered.connect(func(body: Node3D):
        if body == player_root:
            credits += 1
            relays_found += 1
            relay_node.queue_free()
            _set_status("RELAY %d/3 • SCRAP %d" % [relays_found, credits])
    )
    add_child(relay_node)

func _build_monster() -> void:
    active_monster = Node3D.new()
    active_monster.name = "RedBurmaldaFlyer"
    active_monster.position = Vector3(3, 4, -16)
    active_monster.add_to_group("monsters")
    add_child(active_monster)
    var red := _mat(Color(0.52, 0.018, 0.025), Color(0.22, 0.002, 0.005), 0.05, 0.75)
    var pale := _mat(Color(0.78, 0.72, 0.65))
    _mesh_sphere(active_monster, 0.65, Vector3(0, 0.9, 0), red, "MonsterBody")
    _mesh_sphere(active_monster, 0.38, Vector3(0, 1.55, -0.08), red, "MonsterHead")
    _mesh_sphere(active_monster, 0.27, Vector3(0, 1.5, -0.4), pale, "MonsterMask")
    for side in [-1.0, 1.0]:
        var arm := _mesh_sphere(active_monster, 0.16, Vector3(side * 0.72, 0.9, -0.05), red, "MonsterArm")
        arm.scale = Vector3(1, 2.6, 1)
        _mesh_sphere(active_monster, 0.065, Vector3(side * 0.13, 1.58, -0.64), _mat(Color(0.015, 0.005, 0.02), RED), "MonsterEye")
    var words := Label3D.new()
    words.text = "БУРМАЛДА... БУРМАЛДА..."
    words.font_size = 28
    words.position = Vector3(0, 2.35, 0)
    words.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    words.modulate = Color(1, 0.22, 0.25)
    active_monster.add_child(words)
    active_monster.set_meta("bob", 0.0)
    active_monster.set_meta("voice_timer", 0.0)

func _build_companion_shop() -> void:
    var shop := Node3D.new()
    shop.position = Vector3(-4, 0, -5)
    add_child(shop)
    _mesh_box(shop, Vector3(1.6, 1.25, 0.8), Vector3(0, 0.65, 0), _mat(Color(0.09, 0.04, 0.15), PURPLE, 0.6, 0.25), "ScrapShop")
    var sign := Label3D.new()
    sign.text = "COSMIC SHOP\nCOMPANION • 2 SCRAP\nTRIGGER TO BUY"
    sign.font_size = 24
    sign.position = Vector3(0, 1.8, -0.45)
    sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    sign.modulate = Color(0.8, 0.45, 1)
    shop.add_child(sign)
    var preview := _create_companion()
    preview.position = Vector3(0, 1.5, -0.9)
    shop.add_child(preview)

func _create_companion() -> Node3D:
    var buddy := Node3D.new()
    buddy.name = "WingedCosmicCompanion"
    var orange := _mat(Color(1, 0.38, 0.035), Color(0.6, 0.08, 0.005), 0.1, 0.7)
    var white := _mat(Color(0.9, 0.88, 0.98), Color(0.18, 0.12, 0.28), 0.05, 0.65)
    var black := _mat(Color(0.018, 0.008, 0.025))
    _mesh_sphere(buddy, 0.34, Vector3.ZERO, orange, "BuddyBody")
    _mesh_sphere(buddy, 0.22, Vector3(0, 0.04, -0.25), black, "BuddyFace")
    _mesh_sphere(buddy, 0.10, Vector3(0, 0.06, -0.4), _mat(Color(0.65, 0.2, 1), NEON_PURPLE), "BuddyEye")
    for side in [-1.0, 1.0]:
        var wing := _mesh_sphere(buddy, 0.2, Vector3(side * 0.42, 0.16, 0.03), white, "BuddyWing")
        wing.scale = Vector3(1.6, 0.45, 0.8)
        var paw := _mesh_sphere(buddy, 0.17, Vector3(side * 0.22, -0.25, -0.18), _mat(Color(1, 0.68, 0.08)), "BuddyPaw")
    return buddy

func _physics_process(delta: float) -> void:
    if not is_instance_valid(player_root):
        return
    if not flight_enabled and player_root.is_on_floor() == false:
        player_root.velocity.y -= 9.8 * delta
    elif player_root.is_on_floor() and player_root.velocity.y < 0:
        player_root.velocity.y = 0
    if xr_enabled and is_instance_valid(left_hand) and is_instance_valid(right_hand):
        var lp := left_hand.global_position
        var rp := right_hand.global_position
        if have_hand_samples:
            var l_motion := lp - previous_left_hand
            var r_motion := rp - previous_right_hand
            var push := Vector3.ZERO
            if l_motion.length() > 0.012:
                push -= l_motion * 1.9
            if r_motion.length() > 0.012:
                push -= r_motion * 1.9
            player_root.velocity.x += push.x
            player_root.velocity.z += push.z
            if flight_enabled:
                player_root.velocity.y += push.y
        previous_left_hand = lp
        previous_right_hand = rp
        have_hand_samples = true
    player_root.velocity.x = move_toward(player_root.velocity.x, 0.0, delta * 1.4)
    player_root.velocity.z = move_toward(player_root.velocity.z, 0.0, delta * 1.4)
    if flight_enabled:
        player_root.velocity.y = clampf(player_root.velocity.y, -3.0, 3.0)
    player_root.move_and_slide()

func _process(delta: float) -> void:
    hammer_cooldown = maxf(0.0, hammer_cooldown - delta)
    snap_cooldown = maxf(0.0, snap_cooldown - delta)
    _handle_controls(delta)
    _update_monster(delta)
    _update_companion(delta)
    _update_wrist()

func _handle_controls(delta: float) -> void:
    if Input.is_action_just_pressed("toggle_admin"):
        admin_open = not admin_open
        wrist_device.visible = admin_open
    if Input.is_action_just_pressed("hammer_red"):
        _set_hammer_mode(1)
    if Input.is_action_just_pressed("hammer_inverted"):
        _set_hammer_mode(2)
    if Input.is_action_just_pressed("hammer_swing"):
        _swing_hammer()
    if not xr_enabled:
        var move := Vector3.ZERO
        if Input.is_action_pressed("move_forward"): move.z -= 1
        if Input.is_action_pressed("move_back"): move.z += 1
        if Input.is_action_pressed("move_left"): move.x -= 1
        if Input.is_action_pressed("move_right"): move.x += 1
        player_root.velocity.x = move.normalized().x * desktop_speed
        player_root.velocity.z = move.normalized().z * desktop_speed
        if Input.is_action_just_pressed("turn_left"): player_root.rotate_y(deg_to_rad(snap_turn_degrees))
        if Input.is_action_just_pressed("turn_right"): player_root.rotate_y(deg_to_rad(-snap_turn_degrees))
        desktop_camera.global_position = player_root.global_position + Vector3(0, 2.8, 11)
        desktop_camera.look_at(player_root.global_position + Vector3(0, 1.2, -2), Vector3.UP)
        if Input.is_action_just_pressed("interact"):
            _try_interact(desktop_camera.global_position, -desktop_camera.global_transform.basis.z)
    else:
        var x_now := right_hand.is_button_pressed("x_button")
        var y_now := right_hand.is_button_pressed("y_button")
        var trigger_now := right_hand.is_button_pressed("trigger")
        if x_now and y_now:
            if hammer_mode != 2: _set_hammer_mode(2)
        elif x_now and not last_x:
            _set_hammer_mode(1)
        elif not x_now and not y_now and hammer_mode != 0 and not last_x and not last_y:
            _set_hammer_mode(0)
        if trigger_now and not last_trigger:
            _try_interact(right_hand.global_position, -right_hand.global_transform.basis.z)
            _swing_hammer()
        last_x = x_now
        last_y = y_now
        last_trigger = trigger_now

func _update_wrist() -> void:
    if not xr_enabled and is_instance_valid(wrist_device):
        wrist_device.visible = admin_open

func _set_hammer_mode(mode: int) -> void:
    hammer_mode = clampi(mode, 0, 2)
    _make_hammer_model(hammer_root, hammer_mode)
    var mode_name := "YELLOW / NORMAL" if mode == 0 else ("RED" if mode == 1 else "INVERTED BLUE")
    _set_status("HAMMER MODE: " + mode_name)

func _swing_hammer() -> void:
    if hammer_cooldown > 0: return
    hammer_cooldown = 0.45
    if not is_instance_valid(active_monster): return
    var origin := right_hand.global_position if xr_enabled else desktop_camera.global_position
    var forward := -right_hand.global_transform.basis.z if xr_enabled else -desktop_camera.global_transform.basis.z
    var to_monster := active_monster.global_position + Vector3(0, 0.8, 0) - origin
    if to_monster.length() <= hammer_reach + 0.8 and forward.normalized().dot(to_monster.normalized()) > 0.45:
        if hammer_mode == 2:
            _ban_player("bot_sigma")
            active_monster.queue_free()
            active_monster = null
            _set_status("INVERTED HAMMER • LOCAL DEMO TARGET BANNED")
        else:
            var shove := (to_monster.normalized() * -1.0 + Vector3.UP * 0.35).normalized()
            active_monster.global_position += shove * 3.0
            _set_status("HAMMER HIT • MONSTER KNOCKED BACK")

func _try_interact(origin: Vector3, direction: Vector3) -> void:
    if not companion_owned:
        var shop_pos := Vector3(-4, 0.8, -5)
        if origin.distance_to(shop_pos) < 3.2:
            if credits >= 2:
                credits -= 2
                companion_owned = true
                companion_node = _create_companion()
                add_child(companion_node)
                companion_node.global_position = player_root.global_position + Vector3(0.5, 1.8, 0.4)
                _set_status("COMPANION PURCHASED • POINT AT MONSTER + TRIGGER")
            else:
                _set_status("SHOP: NEED 2 SCRAP • COLLECT THE BLUE RELAYS")
            return
    if companion_owned and not companion_in_flight and is_instance_valid(active_monster):
        var target := active_monster.global_position + Vector3(0, 1, 0) - origin
        if target.length() < 30 and direction.normalized().dot(target.normalized()) > 0.93:
            _launch_companion()

func _launch_companion() -> void:
    companion_in_flight = true
    var destination := active_monster.global_position + Vector3(0, 1, 0)
    var tween := create_tween()
    tween.tween_property(companion_node, "global_position", destination, 0.7).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    tween.finished.connect(func():
        if is_instance_valid(companion_node):
            _make_burst(companion_node.global_position)
            companion_node.queue_free()
        companion_node = null
        companion_owned = false
        companion_in_flight = false
        if is_instance_valid(active_monster):
            active_monster.global_position += Vector3(0, 1.5, 0)
        _set_status("COMPANION DETONATED • BUY ANOTHER AT COSMIC SHOP")
    )

func _make_burst(pos: Vector3) -> void:
    for i in range(16):
        var spark := _mesh_sphere(self, 0.07, pos, _mat(Color(1, 0.35, 0.04), Color(1, 0.12, 0.005)), "BuddyBurstSpark")
        var angle := TAU * float(i) / 16.0
        var destination := pos + Vector3(cos(angle), sin(angle * 2.0), sin(angle)) * 1.3
        var tw := create_tween()
        tw.tween_property(spark, "global_position", destination, 0.4)
        tw.parallel().tween_property(spark, "scale", Vector3.ZERO, 0.4)
        tw.finished.connect(spark.queue_free)

func _update_companion(delta: float) -> void:
    if companion_owned and not companion_in_flight and is_instance_valid(companion_node):
        var desired := player_root.global_position + Vector3(0.65, 1.7, 0.4)
        companion_node.global_position = companion_node.global_position.lerp(desired, clampf(delta * 3.0, 0, 1))
        companion_node.rotate_y(delta * 1.5)

func _update_monster(delta: float) -> void:
    if not is_instance_valid(active_monster): return
    var target := player_root.global_position + Vector3(0, 1.2, 0)
    var dist := active_monster.global_position.distance_to(target)
    if dist < 28:
        active_monster.global_position = active_monster.global_position.move_toward(target, delta * (1.35 if dist > 4 else 0.35))
    var bob := float(active_monster.get_meta("bob", 0.0)) + delta * 2.0
    active_monster.set_meta("bob", bob)
    active_monster.global_position.y = 3.8 + sin(bob) * 0.25
    var timer := float(active_monster.get_meta("voice_timer", 0.0)) - delta
    if timer <= 0:
        timer = 6.0
        var voices := DisplayServer.tts_get_voices()
        if voices.size() > 0:
            DisplayServer.tts_speak("Бурмалда. Бурмалда. Бурмалда.", str(voices[0].get("id", "")), 1.0, 0.75, 0.75, 35)
    active_monster.set_meta("voice_timer", timer)

func _show_player_list() -> void:
    _set_status("MONKEY LIST: TP / BAN / MUTE / FREEZE • see wrist panel")

func _teleport_spawn() -> void:
    player_root.global_position = Vector3(0, 0, 6)
    _set_status("TELEPORTED TO SPAWN")

func _teleport_to_player(player_id: String) -> void:
    if player_id == "local_owner":
        _set_status("THAT IS YOU — CANNOT TELEPORT TO YOURSELF")
    else:
        player_root.global_position = Vector3(2, 0, -2)
        _set_status("TP TO %s • OFFLINE BOT DEMO" % player_id)

func _ban_player(player_id: String) -> void:
    if player_id == "local_owner":
        _set_status("OWNER PROTECTED")
        return
    banned_players[player_id] = true
    _set_status("BAN %s • LOCAL DEMO ONLY (NO MULTIPLAYER SERVER)" % player_id)

func _mute_player(player_id: String) -> void:
    muted_players[player_id] = not bool(muted_players.get(player_id, false))
    _set_status("%s %s • LOCAL DEMO" % ["MUTED" if muted_players[player_id] else "UNMUTED", player_id])

func _toggle_flight() -> void:
    flight_enabled = not flight_enabled
    if not flight_enabled:
        player_root.velocity.y = 0
    _set_status("FLIGHT: %s" % ("ON" if flight_enabled else "OFF"))

func _toggle_speed() -> void:
    desktop_speed = 8.0 if desktop_speed < 6.0 else 4.0
    _set_status("SPEED BOOST: %s" % ("ON" if desktop_speed > 6 else "OFF"))

func _toggle_noclip() -> void:
    noclip_enabled = not noclip_enabled
    if is_instance_valid(player_root.get_node_or_null("CollisionShape3D")):
        player_root.get_node("CollisionShape3D").disabled = noclip_enabled
    _set_status("NO CLIP: %s" % ("ON" if noclip_enabled else "OFF"))

func _give_resources() -> void:
    credits += 100
    _refresh_status()

func _refresh_status() -> void:
    _set_status("SCRAP: %d • RELAYS: %d/3" % [credits, relays_found])

func _set_status(message: String) -> void:
    if is_instance_valid(status_label):
        status_label.text = message
    else:
        status_label = Label3D.new()
        status_label.font_size = 22
        status_label.position = Vector3(0, 3.6, -2.0)
        status_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        status_label.modulate = Color(0.9, 0.72, 1)
        add_child(status_label)
        status_label.text = message
