extends Node3D

# PRIMATE VR STARTER
# First milestone: OpenXR camera/controllers + arm-swing locomotion + 35-degree snap turn.
# This is a starting point for Quest testing, not a finished game.

@export var max_speed: float = 6.5
@export var push_gain: float = 1.15
@export var hand_radius: float = 0.14
@export var snap_degrees: float = 35.0
@export var gravity: float = 9.8

var xr_interface: XRInterface
var xr_enabled := false

var player: CharacterBody3D
var xr_origin: XROrigin3D
var camera: XRCamera3D
var left_hand: XRController3D
var right_hand: XRController3D

var previous_hand_positions: Dictionary = {}
var snap_cooldown := 0.0
var status_label: Label3D

func _ready() -> void:
    _create_player()
    _create_test_room()
    _create_status_label()
    _start_openxr()

func _start_openxr() -> void:
    xr_interface = XRServer.find_interface("OpenXR")
    if xr_interface and xr_interface.is_initialized() == false:
        xr_enabled = xr_interface.initialize()
        if xr_enabled:
            get_viewport().use_xr = true
            status_label.text = "OPENXR ACTIVE\nMove your hands against surfaces to push"
        else:
            status_label.text = "OpenXR did not initialize\nCheck Project Settings > XR"
    else:
        status_label.text = "Desktop preview\nEnable OpenXR for Quest"

func _create_player() -> void:
    player = CharacterBody3D.new()
    player.name = "PlayerBody"
    player.position = Vector3(0, 0.15, 4)
    add_child(player)

    var body_collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.24
    capsule.height = 1.35
    body_collision.shape = capsule
    body_collision.position.y = 0.78
    player.add_child(body_collision)

    xr_origin = XROrigin3D.new()
    xr_origin.name = "XROrigin3D"
    player.add_child(xr_origin)

    camera = XRCamera3D.new()
    camera.name = "XRCamera3D"
    camera.position.y = 1.6
    xr_origin.add_child(camera)

    left_hand = XRController3D.new()
    left_hand.name = "LeftHand"
    left_hand.tracker = &"left_hand"
    left_hand.pose = &"default"
    xr_origin.add_child(left_hand)

    right_hand = XRController3D.new()
    right_hand.name = "RightHand"
    right_hand.tracker = &"right_hand"
    right_hand.pose = &"default"
    xr_origin.add_child(right_hand)

func _create_test_room() -> void:
    _add_box(Vector3(0, -0.25, 0), Vector3(16, 0.5, 16), Color(0.18, 0.16, 0.15))
    _add_box(Vector3(0, 2.0, -8), Vector3(16, 4, 0.35), Color(0.25, 0.12, 0.08))
    _add_box(Vector3(-8, 2.0, 0), Vector3(0.35, 4, 16), Color(0.25, 0.12, 0.08))
    _add_box(Vector3(8, 2.0, 0), Vector3(0.35, 4, 16), Color(0.25, 0.12, 0.08))
    _add_box(Vector3(0, 2.0, 8), Vector3(16, 4, 0.35), Color(0.25, 0.12, 0.08))

    # Blocks to test hand pushing and climbing.
    _add_box(Vector3(-2.2, 0.8, -1.5), Vector3(2.0, 1.6, 2.0), Color(0.42, 0.20, 0.10))
    _add_box(Vector3(2.0, 1.2, -2.7), Vector3(2.4, 2.4, 1.4), Color(0.34, 0.17, 0.10))
    _add_box(Vector3(0.0, 2.5, -5.0), Vector3(4.0, 0.35, 1.0), Color(0.45, 0.25, 0.12))

    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.018, 0.015, 0.02)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.45, 0.34, 0.26)
    env.ambient_light_energy = 0.65
    world_env.environment = env
    add_child(world_env)

    var light := DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-55, -25, 0)
    light.light_energy = 0.8
    add_child(light)

func _create_status_label() -> void:
    status_label = Label3D.new()
    status_label.text = "Starting..."
    status_label.font_size = 32
    status_label.position = Vector3(0, 2.8, -3.0)
    status_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    status_label.modulate = Color(1.0, 0.55, 0.25)
    add_child(status_label)

func _physics_process(delta: float) -> void:
    if snap_cooldown > 0.0:
        snap_cooldown -= delta

    _apply_gravity(delta)

    if xr_enabled:
        _process_hand_push(left_hand, "left", delta)
        _process_hand_push(right_hand, "right", delta)

    _apply_snap_turn()
    player.velocity = player.velocity.limit_length(max_speed)
    player.move_and_slide()

func _apply_gravity(delta: float) -> void:
    if not player.is_on_floor():
        player.velocity.y -= gravity * delta
    elif player.velocity.y < 0.0:
        player.velocity.y = 0.0

func _process_hand_push(hand: XRController3D, hand_id: String, delta: float) -> void:
    if hand == null or not hand.get_is_active():
        return

    var current_pos: Vector3 = hand.global_position
    if not previous_hand_positions.has(hand_id):
        previous_hand_positions[hand_id] = current_pos
        return

    var previous_pos: Vector3 = previous_hand_positions[hand_id]
    var hand_motion: Vector3 = current_pos - previous_pos
    previous_hand_positions[hand_id] = current_pos

    # Ignore tracking jumps and tiny tracking noise.
    if hand_motion.length() < 0.004 or hand_motion.length() > 0.30:
        return

    if _hand_touches_world(current_pos):
        # Push the player opposite to the hand's movement.
        var push_velocity := -hand_motion / maxf(delta, 0.001)
        push_velocity.y = clampf(push_velocity.y, -2.0, 4.5)
        player.velocity += push_velocity * push_gain

func _hand_touches_world(world_pos: Vector3) -> bool:
    var sphere := SphereShape3D.new()
    sphere.radius = hand_radius

    var query := PhysicsShapeQueryParameters3D.new()
    query.shape = sphere
    query.transform = Transform3D(Basis.IDENTITY, world_pos)
    query.exclude = [player.get_rid()]
    query.collide_with_bodies = true
    query.collide_with_areas = false

    var results := get_world_3d().direct_space_state.intersect_shape(query, 8)
    return not results.is_empty()

func _apply_snap_turn() -> void:
    if snap_cooldown > 0.0:
        return

    if Input.is_action_just_pressed("snap_left"):
        xr_origin.rotate_y(deg_to_rad(snap_degrees))
        snap_cooldown = 0.22
    elif Input.is_action_just_pressed("snap_right"):
        xr_origin.rotate_y(deg_to_rad(-snap_degrees))
        snap_cooldown = 0.22

func _add_box(pos: Vector3, size: Vector3, color: Color) -> void:
    var mesh_instance := MeshInstance3D.new()
    var box_mesh := BoxMesh.new()
    box_mesh.size = size
    mesh_instance.mesh = box_mesh
    mesh_instance.position = pos

    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.roughness = 0.82
    mesh_instance.material_override = material
    add_child(mesh_instance)

    var static_body := StaticBody3D.new()
    static_body.position = pos
    var collision := CollisionShape3D.new()
    var box_shape := BoxShape3D.new()
    box_shape.size = size
    collision.shape = box_shape
    static_body.add_child(collision)
    add_child(static_body)
