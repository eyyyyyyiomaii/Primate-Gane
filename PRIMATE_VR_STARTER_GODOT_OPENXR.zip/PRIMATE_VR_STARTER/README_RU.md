# PRIMATE VR STARTER — Godot 4 + OpenXR

## Included
- XR origin, XR camera, left/right XR controllers
- CharacterBody3D player body
- Experimental hand-contact push locomotion
- 35-degree snap turn actions (Q/E in desktop preview)
- Small collision test room

## Import
1. Extract the ZIP on the Quest 3S or Android device.
2. Open Godot XR Editor.
3. Choose Import and select `project.godot`.
4. Open the project and run the main scene.

## OpenXR setup
In Godot Project Settings, enable XR/OpenXR and check the OpenXR action map.
The project uses controller trackers `left_hand` and `right_hand`, pose `default`.
Bind the `snap_left` and `snap_right` actions to left/right stick clicks or directions
in your OpenXR action map if the editor/runtime does not provide those bindings automatically.

## Important
This is an early movement test, not a finished game. The hand-push implementation must be tuned
on the real Quest 3S. No online multiplayer, enemy AI, or final art is included yet.
The hand-contact query uses collision bodies in the world; only surfaces with collision will push.
