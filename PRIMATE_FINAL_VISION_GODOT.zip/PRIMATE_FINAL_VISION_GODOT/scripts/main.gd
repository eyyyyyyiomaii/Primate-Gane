extends Node3D
@export var snap_turn_degrees := 35.0
@export var move_speed := 4.5
var xr_on := false
var xr_origin: XROrigin3D
var player: CharacterBody3D
var desktop_camera: Camera3D
var snap_timer := 0.0
var info: Label3D
var relays := 0
var objective_text := "Find the three power relays"

func _ready():
    build_environment()
    build_level()
    build_player()
    build_hud()
    setup_xr()

func build_environment():
    var we=WorldEnvironment.new()
    var e=Environment.new()
    e.background_mode=Environment.BG_COLOR
    e.background_color=Color(0.008,0.012,0.016)
    e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color=Color(0.34,0.39,0.42)
    e.ambient_light_energy=0.55
    we.environment=e
    add_child(we)
    var l=DirectionalLight3D.new()
    l.rotation_degrees=Vector3(-48,-25,0)
    l.light_energy=0.7
    add_child(l)

func build_player():
    player=CharacterBody3D.new()
    player.position=Vector3(0,0.1,7)
    add_child(player)
    var cs=CollisionShape3D.new()
    var cap=CapsuleShape3D.new()
    cap.radius=0.24
    cap.height=1.35
    cs.shape=cap
    cs.position.y=0.75
    player.add_child(cs)
    xr_origin=XROrigin3D.new()
    player.add_child(xr_origin)
    var cam=XRCamera3D.new()
    cam.position.y=1.6
    xr_origin.add_child(cam)
    for side in ["left","right"]:
        var hand=XRController3D.new()
        hand.tracker=StringName(side+"_hand")
        hand.pose=&"default"
        hand.name=side+"Hand"
        xr_origin.add_child(hand)
    desktop_camera=Camera3D.new()
    desktop_camera.position=Vector3(0,2.1,11)
    desktop_camera.rotation_degrees=Vector3(-9,0,0)
    desktop_camera.current=true
    add_child(desktop_camera)

func setup_xr():
    var iface=XRServer.find_interface("OpenXR")
    if iface and (iface.is_initialized() or iface.initialize()):
        xr_on=true
        get_viewport().use_xr=true
        desktop_camera.current=false
        info.text="OPENXR ACTIVE"
    else:
        info.text="DESKTOP PREVIEW — enable OpenXR for Quest"

func build_hud():
    info=Label3D.new()
    info.text="PRIMATE"
    info.font_size=38
    info.position=Vector3(0,3,-4)
    info.billboard=BaseMaterial3D.BILLBOARD_ENABLED
    info.modulate=Color(1,0.63,0.32)
    add_child(info)

func _physics_process(delta):
    if not player: return
    if not player.is_on_floor(): player.velocity.y-=9.8*delta
    else: player.velocity.y=maxf(player.velocity.y,0)
    if snap_timer>0: snap_timer-=delta
    if xr_on and snap_timer<=0:
        if Input.is_action_just_pressed("ui_left"):
            xr_origin.rotate_y(deg_to_rad(snap_turn_degrees)); snap_timer=0.25
        elif Input.is_action_just_pressed("ui_right"):
            xr_origin.rotate_y(deg_to_rad(-snap_turn_degrees)); snap_timer=0.25
    player.move_and_slide()

func add_box(n,p,s,c):
    var m=MeshInstance3D.new()
    var bm=BoxMesh.new(); bm.size=s; m.mesh=bm; m.position=p
    var mat=StandardMaterial3D.new(); mat.albedo_color=c; mat.roughness=0.88
    m.material_override=mat; add_child(m)
    var b=StaticBody3D.new(); b.position=p
    var cs=CollisionShape3D.new(); var sh=BoxShape3D.new(); sh.size=s; cs.shape=sh
    b.add_child(cs); add_child(b)

func add_cylinder(n,p,r,h,c):
    var m=MeshInstance3D.new()
    var cm=CylinderMesh.new(); cm.top_radius=r; cm.bottom_radius=r; cm.height=h
    m.mesh=cm; m.position=p
    var mat=StandardMaterial3D.new(); mat.albedo_color=c; m.material_override=mat
    add_child(m)

func add_tree(p):
    add_cylinder("Trunk",p+Vector3(0,1.3,0),0.22,2.6,Color(0.16,0.09,0.045))
    var crown=MeshInstance3D.new()
    var sm=SphereMesh.new(); sm.radius=1.15; sm.height=2.3; crown.mesh=sm
    crown.position=p+Vector3(0,3,0)
    var mat=StandardMaterial3D.new(); mat.albedo_color=Color(0.045,0.16,0.085); mat.roughness=1
    crown.material_override=mat; add_child(crown)

func relay(p):
    var area=Area3D.new()
    area.position=p
    var cs=CollisionShape3D.new(); var sh=SphereShape3D.new(); sh.radius=1.0; cs.shape=sh
    area.add_child(cs); add_child(area)
    var visual=MeshInstance3D.new()
    var mesh=BoxMesh.new(); mesh.size=Vector3(0.5,0.8,0.35); visual.mesh=mesh
    var mat=StandardMaterial3D.new(); mat.albedo_color=Color(0.1,0.65,0.9); mat.emission_enabled=true
    mat.emission=Color(0.05,0.35,0.8); visual.material_override=mat
    area.add_child(visual)
    area.body_entered.connect(func(body):
        if body==player and not area.is_queued_for_deletion():
            relays+=1
            area.queue_free()
            info.text="Relay %d/3 — %s" % [relays, "Exit powered!" if relays==3 else "Find the next relay"]
    )

func monster(p):
    var enemy=Node3D.new()
    enemy.position=p
    add_child(enemy)
    var body=MeshInstance3D.new()
    var sm=SphereMesh.new(); sm.radius=0.8; sm.height=1.8; body.mesh=sm
    var mat=StandardMaterial3D.new(); mat.albedo_color=Color(0.025,0.018,0.025)
    mat.emission_enabled=true; mat.emission=Color(0.08,0.005,0.025)
    body.material_override=mat; body.position.y=1.1; enemy.add_child(body)
    for x in [-0.28,0.28]:
        var eye=MeshInstance3D.new(); var em=SphereMesh.new(); em.radius=0.075; eye.mesh=em
        var mm=StandardMaterial3D.new(); mm.albedo_color=Color(1,0.25,0.08); mm.emission_enabled=true
        mm.emission=Color(0.35,0.035,0.01); eye.material_override=mm
        eye.position=Vector3(x,1.25,-0.68); enemy.add_child(eye)
    var timer=Timer.new(); timer.wait_time=0.04; timer.autostart=true; enemy.add_child(timer)
    timer.timeout.connect(func():
        if is_instance_valid(player):
            var target=player.global_position; target.y=enemy.global_position.y
            var d=enemy.global_position.distance_to(target)
            if d<12:
                enemy.global_position=enemy.global_position.move_toward(target,0.04 if d>2 else 0.0)
    )

func build_level():
    # Dark industrial complex with connected rooms, platforms and corridors.
    add_box("Ground",Vector3(0,-0.3,0),Vector3(42,0.6,42),Color(0.12,0.13,0.14))
    add_box("MainHall",Vector3(0,2,-12),Vector3(26,4,0.5),Color(0.22,0.17,0.14))
    add_box("WestWall",Vector3(-13,2,0),Vector3(0.5,4,26),Color(0.19,0.16,0.15))
    add_box("EastWall",Vector3(13,2,0),Vector3(0.5,4,26),Color(0.19,0.16,0.15))
    add_box("StaffRoom",Vector3(-7,1.5,-4),Vector3(7,3,7),Color(0.24,0.19,0.16))
    add_box("Catwalk",Vector3(4,2.5,-7),Vector3(9,0.3,2),Color(0.35,0.22,0.13))
    add_box("Storage",Vector3(6,1.2,5),Vector3(8,2.4,7),Color(0.17,0.19,0.2))
    relay(Vector3(-5,0.8,-7)); relay(Vector3(7,0.8,-8)); relay(Vector3(7,0.8,6))
    monster(Vector3(0,0,-10))
    # Visible luminous objective marker
    add_box("ExitDoor",Vector3(0,1.5,-19),Vector3(3,3,0.3),Color(0.08,0.28,0.18))
    info.text="PRIMATE: NIGHT SHIFT\nRestore 3 relays. Find the exit."

