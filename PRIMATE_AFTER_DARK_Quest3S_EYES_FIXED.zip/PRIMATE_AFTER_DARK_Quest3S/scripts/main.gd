extends Node3D
## PRIMATE: AFTER DARK — original standalone VR horror prototype.
## Generated geometry is intentionally lightweight for a Quest-class headset.

const PLAYER_START := Vector3(0, 0, 8)
const BATTERY_TOTAL := 5

var xr_origin: XROrigin3D
var head: XRCamera3D
var left: XRController3D
var right: XRController3D
var flashlight: SpotLight3D
var enemy: Node3D
var hud: Label3D
var message_time := 0.0
var batteries := 0
var lives := 3
var stamina := 100.0
var flashlight_enabled := true
var dev_menu_open := false
var vip_unlocked := false
var secret_unlocked := false
var cosmetics := ["Rust Crown", "Moss Mask", "Static Halo"]
var selected_cosmetic := 0
var pickup_nodes: Array[Node3D] = []
var rng := RandomNumberGenerator.new()
var enemy_speed := 1.0
var game_over := false
var previous_toggle := false

func _ready() -> void:
	rng.randomize()
	_make_environment()
	_make_level()
	_make_player()
	_make_pickups()
	_make_enemy()
	_make_hud()
	_notice("DON'T LET IT HEAR YOU")

func _process(delta: float) -> void:
	if game_over:
		return
	message_time = maxf(0.0, message_time - delta)
	_move_player(delta)
	_move_enemy(delta)
	_update_flashlight(delta)
	_update_pickups()
	_update_secret_and_exit()
	_update_hud()

func _make_environment() -> void:
	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.006, 0.009, 0.008)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.22, 0.27, 0.22)
	env.ambient_light_energy = 0.22
	env_node.environment = env
	add_child(env_node)

func _mat(color: Color, glow: bool = false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.94
	if glow:
		m.emission_enabled = true
		m.emission = color
	return m

func _box(parent: Node3D, name: String, pos: Vector3, size: Vector3, color: Color) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = name
	body.position = pos
	var mesh := MeshInstance3D.new()
	var shape_mesh := BoxMesh.new()
	shape_mesh.size = size
	mesh.mesh = shape_mesh
	mesh.material_override = _mat(color)
	body.add_child(mesh)
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	col.shape = shape
	body.add_child(col)
	parent.add_child(body)
	return body

func _make_level() -> void:
	_box(self, "MainFloor", Vector3(0,-0.2,0), Vector3(30,0.4,30), Color(0.10,0.13,0.11))
	_box(self, "Ceiling", Vector3(0,4.8,0), Vector3(30,0.3,30), Color(0.025,0.035,0.03))
	for spec in [
		[Vector3(0,2.3,-15), Vector3(30,4.6,.35)],
		[Vector3(0,2.3,15), Vector3(30,4.6,.35)],
		[Vector3(-15,2.3,0), Vector3(.35,4.6,30)],
		[Vector3(15,2.3,0), Vector3(.35,4.6,30)]
	]:
		_box(self, "ConcreteWall", spec[0], spec[1], Color(0.075,0.095,0.08))

	# Corridors, pillars and abandoned machinery silhouettes.
	for p in [Vector3(-8,1.8,-7),Vector3(7,1.8,-8),Vector3(-8,1.8,6),Vector3(8,1.8,7)]:
		_box(self,"Pillar",p,Vector3(1.0,3.6,1.0),Color(0.12,0.15,0.13))
	for p in [Vector3(-3,.7,-8),Vector3(4,.7,-3),Vector3(-6,.7,1),Vector3(5,.7,10)]:
		_box(self,"OldCrate",p,Vector3(1.8,1.4,1.8),Color(0.12,0.14,0.12))

	# VIP showroom attached to the east side.
	_box(self,"VIPFloor",Vector3(11,0,0),Vector3(6,.3,9),Color(0.12,0.16,0.13))
	_box(self,"VIPBack",Vector3(11,2.2,-4.5),Vector3(6,4.4,.25),Color(0.08,0.12,0.1))
	_box(self,"VIPSide",Vector3(14,2.2,0),Vector3(.25,4.4,9),Color(0.08,0.12,0.1))
	_box(self,"VIPFrontLeft",Vector3(9.4,2.2,4.5),Vector3(2.8,4.4,.25),Color(0.08,0.12,0.1))
	_box(self,"VIPFrontRight",Vector3(13.3,2.2,4.5),Vector3(1.4,4.4,.25),Color(0.08,0.12,0.1))
	_box(self,"VIPDisplayPlinth",Vector3(11,0.55,-1),Vector3(2,.9,1.5),Color(0.18,0.22,0.18))
	_make_mirror(Vector3(11,2.1,-4.30))

	# Hidden creator nook: tucked behind a false panel in the far corner.
	_box(self,"SecretRoomFloor",Vector3(-12.2,0,-12.1),Vector3(4,.3,4),Color(0.08,0.11,0.09))
	_box(self,"SecretBack",Vector3(-12.2,2,-14.1),Vector3(4,4,.2),Color(0.04,0.07,0.05))
	_box(self,"SecretLeft",Vector3(-14.2,2,-12.1),Vector3(.2,4,4),Color(0.04,0.07,0.05))
	_box(self,"SecretRight",Vector3(-10.2,2,-12.1),Vector3(.2,4,4),Color(0.04,0.07,0.05))
	var door := _box(self,"HiddenDoor",Vector3(-12.2,1.4,-10.0),Vector3(1.3,2.8,.18),Color(0.025,0.035,0.03))
	door.set_meta("secret_door",true)

	# Exit arch, bright enough to read in the dark.
	_box(self,"ExitPanel",Vector3(0,1.5,-14.65),Vector3(2.4,3,.2),Color(0.05,0.18,0.1))
	var exit_light := OmniLight3D.new()
	exit_light.position = Vector3(0,2.5,-13.7)
	exit_light.light_color = Color(.2,1,.4)
	exit_light.light_energy = 1.0
	exit_light.omni_range = 4
	add_child(exit_light)

func _make_mirror(pos: Vector3) -> void:
	# A reflective-looking display panel; true live reflection requires a SubViewport setup.
	var panel := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(2.1,2.8)
	panel.mesh = plane
	panel.position = pos
	panel.rotation.y = PI
	panel.material_override = _mat(Color(.20,.29,.26))
	add_child(panel)
	var frame := _box(self,"MirrorFrame",pos+Vector3(0,0,-.06),Vector3(2.3,3,.12),Color(.28,.34,.29))
	frame.get_child(0).material_override = _mat(Color(.28,.34,.29))

func _make_player() -> void:
	var xr := XRServer.find_interface("OpenXR")
	if xr and xr.is_initialized():
		get_viewport().use_xr = true
	else:
		push_warning("OpenXR not initialized: run as an Android OpenXR build on Quest.")
	xr_origin = XROrigin3D.new()
	xr_origin.position = PLAYER_START
	add_child(xr_origin)
	head = XRCamera3D.new()
	head.position = Vector3(0,1.65,0)
	xr_origin.add_child(head)
	left = XRController3D.new()
	left.tracker = "left_hand"
	left.pose = "default"
	xr_origin.add_child(left)
	right = XRController3D.new()
	right.tracker = "right_hand"
	right.pose = "default"
	xr_origin.add_child(right)
	flashlight = SpotLight3D.new()
	flashlight.position = Vector3(.1,-.08,-.2)
	flashlight.light_color = Color(.82,1,.82)
	flashlight.light_energy = 3.2
	flashlight.spot_range = 18
	flashlight.spot_angle = 32
	right.add_child(flashlight)

func _make_hud() -> void:
	hud = Label3D.new()
	hud.position = Vector3(0,.15,-2.0)
	hud.font_size = 42
	hud.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	hud.modulate = Color(.78,1,.82)
	head.add_child(hud)

func _make_pickups() -> void:
	var spots := [Vector3(-10,.45,-8),Vector3(8,.45,-5),Vector3(-8,.45,8),Vector3(8,.45,10),Vector3(0,.45,-1)]
	for p in spots:
		var item := Node3D.new()
		item.position = p
		var mesh := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = .22
		sphere.height = .44
		mesh.mesh = sphere
		mesh.material_override = _mat(Color(.35,1,.25),true)
		item.add_child(mesh)
		var glow := OmniLight3D.new()
		glow.light_color = Color(.3,1,.2)
		glow.light_energy = .65
		glow.omni_range = 2.2
		item.add_child(glow)
		add_child(item)
		pickup_nodes.append(item)

func _make_enemy() -> void:
	enemy = Node3D.new()
	enemy.position = Vector3(0,0,-8)
	var torso := MeshInstance3D.new()
	var capsule := CapsuleMesh.new()
	capsule.radius = .48
	capsule.height = 2.1
	torso.mesh = capsule
	torso.material_override = _mat(Color(.025,.032,.028))
	enemy.add_child(torso)
	# Eyes are deliberately tiny and dim: eerie when seen up close,
	# but they should never wash out the player's night vision.
	for x in [-.15,.15]:
		var eye := MeshInstance3D.new()
		var ball := SphereMesh.new()
		ball.radius = .038
		ball.height = .075
		eye.mesh = ball
		eye.position = Vector3(x,.46,-.435)
		var eye_mat := StandardMaterial3D.new()
		eye_mat.albedo_color = Color(0.20, 0.075, 0.025)
		eye_mat.emission_enabled = true
		eye_mat.emission = Color(0.055, 0.012, 0.003)
		eye_mat.roughness = 0.85
		eye.material_override = eye_mat
		enemy.add_child(eye)
	add_child(enemy)

func _move_player(delta: float) -> void:
	if not xr_origin or not head or not left:
		return
	var stick := left.get_vector2("primary")
	var forward := -head.global_transform.basis.z
	forward.y = 0
	forward = forward.normalized()
	var right_vec := head.global_transform.basis.x
	right_vec.y = 0
	right_vec = right_vec.normalized()
	var direction := right_vec * stick.x + forward * stick.y
	if direction.length() > .15:
		var speed := 2.3
		if left.is_button_pressed("primary_click") and stamina > 1:
			speed = 3.6
			stamina = maxf(0,stamina-28*delta)
		else:
			stamina = minf(100,stamina+18*delta)
		xr_origin.global_position += direction.normalized() * speed * delta
	xr_origin.global_position.x = clampf(xr_origin.global_position.x,-13.5,13.5)
	xr_origin.global_position.z = clampf(xr_origin.global_position.z,-13.5,13.5)

func _move_enemy(delta: float) -> void:
	if not enemy:
		return
	var target := xr_origin.global_position
	target.y = 0
	var here := enemy.global_position
	here.y = 0
	var distance := here.distance_to(target)
	var speed := enemy_speed if distance < 11 else .25
	if distance > .85:
		enemy.global_position = enemy.global_position.move_toward(Vector3(target.x,0,target.z),speed*delta)
		enemy.look_at(Vector3(target.x,1,target.z),Vector3.UP)
	if distance < .85:
		lives -= 1
		_notice("IT FOUND YOU. RUN.")
		enemy.global_position = Vector3(rng.randf_range(-10,10),0,rng.randf_range(-10,10))
		if lives <= 0:
			_finish(false)

func _update_flashlight(delta: float) -> void:
	if right:
		var toggle := right.is_button_pressed("trigger_click")
		if toggle and not previous_toggle:
			flashlight_enabled = not flashlight_enabled
		previous_toggle = toggle
	if flashlight:
		flashlight.visible = flashlight_enabled

func _update_pickups() -> void:
	for item in pickup_nodes.duplicate():
		if is_instance_valid(item) and item.global_position.distance_to(xr_origin.global_position) < 1.15:
			batteries += 1
			pickup_nodes.erase(item)
			item.queue_free()
			_notice("POWER CELL RECOVERED")

func _update_secret_and_exit() -> void:
	var p := xr_origin.global_position
	# Secret door opens after finding the tiny three-symbol clue near the VIP display.
	if batteries >= 3 and p.distance_to(Vector3(-12.2,0,-9.5)) < 1.8 and not secret_unlocked:
		secret_unlocked = true
		_notice("A HIDDEN LOCK CLICKS OPEN...")
	if secret_unlocked and p.distance_to(Vector3(-12.2,0,-12.0)) < 1.2:
		_notice("CREATOR'S HIDEOUT — YOU FOUND IT")
	if batteries >= BATTERY_TOTAL and p.distance_to(Vector3(0,0,-14)) < 1.8:
		_finish(true)
	# VIP door is unlocked by collecting all batteries in this prototype.
	if batteries == BATTERY_TOTAL and not vip_unlocked:
		vip_unlocked = true
		_notice("VIP SHOWROOM UNLOCKED")

func _update_hud() -> void:
	if not hud:
		return
	if message_time <= 0:
		hud.text = "CELLS %d/%d   HEARTS %d" % [batteries,BATTERY_TOTAL,lives]

func _notice(text: String) -> void:
	if hud:
		hud.text = text
	message_time = 2.5

func _finish(win: bool) -> void:
	game_over = true
	if hud:
		hud.text = "YOU ESCAPED" if win else "THE DARK TOOK YOU"

func _input(event: InputEvent) -> void:
	# Desktop/editor fallback for testing; not intended as the Quest control scheme.
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F:
			flashlight_enabled = not flashlight_enabled
		elif event.keycode == KEY_M:
			dev_menu_open = not dev_menu_open
			_notice("DEV PANEL: F flashlight | 1-3 cosmetics | +/- monster speed")
		elif dev_menu_open:
			if event.keycode == KEY_1:
				selected_cosmetic = 0
			elif event.keycode == KEY_2:
				selected_cosmetic = 1
			elif event.keycode == KEY_3:
				selected_cosmetic = 2
			elif event.keycode == KEY_KP_ADD or event.keycode == KEY_EQUAL:
				enemy_speed = minf(2.5,enemy_speed+.15)
			elif event.keycode == KEY_KP_SUBTRACT or event.keycode == KEY_MINUS:
				enemy_speed = maxf(.4,enemy_speed-.15)
