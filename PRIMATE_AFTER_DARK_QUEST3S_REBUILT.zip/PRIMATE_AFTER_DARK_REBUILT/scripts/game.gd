extends CharacterBody3D

# PRIMATE: AFTER DARK — standalone original VR prototype for Meta Quest 3S.
# Locomotion: controller-hand collision and push-off, with a tunable speed cap.

const SNAP_DEGREES := 35.0
const SNAP_RADIANS := deg_to_rad(SNAP_DEGREES)
const MAX_SPEED := 7.2
const PUSH_GAIN := 23.0
const GRAVITY := 12.0
const HAND_RADIUS := 0.145
const WORLD_MASK := 1

var xr_interface: XRInterface
var xr_active := false
var origin: XROrigin3D
var camera: XRCamera3D
var left_hand: XRController3D
var right_hand: XRController3D
var previous_left := Vector3.ZERO
var previous_right := Vector3.ZERO
var have_hand_history := false
var snap_ready := true
var snap_axis := 0.0
var cores_found := 0
var game_over := false
var hud: Label
var objective_label: Label
var message_label: Label
var monster: CharacterBody3D
var monster_home := Vector3(0, 0, -35)
var monster_speed := 2.65
var flashlight_on := true
var trigger_was_pressed := false
var flashlight: SpotLight3D
var ambience: AudioStreamPlayer
var battery := 100.0
var relay_positions := [Vector3(-36, 1.0, -26), Vector3(48, 1.0, -58), Vector3(4, 1.0, 46)]
var relays: Array[Area3D] = []
var rng := RandomNumberGenerator.new()

func _ready() -> void:
    rng.randomize()
    _setup_xr()
    _build_world()
    _build_player_rig()
    _build_hud()
    _build_audio_and_flashlight()
    _spawn_monster()
    _spawn_relays()
    _show_message("NIGHT SHIFT // RESTORE 3 RELAYS", 5.0)

func _setup_xr() -> void:
    xr_interface = XRServer.find_interface("OpenXR")
    if xr_interface and xr_interface.is_initialized():
        xr_active = true
    elif xr_interface:
        xr_active = xr_interface.initialize()
    if xr_active:
        get_viewport().use_xr = true
    else:
        push_warning("OpenXR is not active. Desktop preview controls are enabled.")

func _build_player_rig() -> void:
    origin = XROrigin3D.new()
    origin.name = "XROrigin3D"
    add_child(origin)
    camera = XRCamera3D.new()
    camera.name = "XRCamera3D"
    camera.position = Vector3(0, 1.65, 0)
    camera.current = true
    origin.add_child(camera)
    left_hand = _make_controller("LeftHand", 1, Vector3(-0.3, 1.15, -0.45))
    right_hand = _make_controller("RightHand", 2, Vector3(0.3, 1.15, -0.45))
    origin.add_child(left_hand)
    origin.add_child(right_hand)
    _add_hand_visual(left_hand, Color(0.16, 0.72, 0.66))
    _add_hand_visual(right_hand, Color(0.83, 0.49, 0.25))
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.27
    capsule.height = 1.35
    var body_collision := CollisionShape3D.new()
    body_collision.shape = capsule
    body_collision.position.y = 0.78
    add_child(body_collision)
    collision_layer = 2
    collision_mask = WORLD_MASK

func _make_controller(node_name: String, tracker_id: int, fallback: Vector3) -> XRController3D:
    var c := XRController3D.new()
    c.name = node_name
    c.tracker = StringName("left_hand" if tracker_id == 1 else "right_hand")
    c.position = fallback
    c.pose = StringName("grip")
    return c

func _add_hand_visual(hand: XRController3D, tint: Color) -> void:
    var mesh := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = HAND_RADIUS
    sphere.height = HAND_RADIUS * 2.0
    mesh.mesh = sphere
    mesh.material_override = _mat(tint, 0.28, 0.0)
    hand.add_child(mesh)
    var glow := OmniLight3D.new()
    glow.light_color = tint
    glow.light_energy = 0.18
    glow.omni_range = 1.2
    hand.add_child(glow)

func _build_world() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.008, 0.022, 0.033)
    sky_mat.sky_horizon_color = Color(0.045, 0.085, 0.09)
    sky_mat.ground_bottom_color = Color(0.006, 0.012, 0.014)
    sky_mat.ground_horizon_color = Color(0.025, 0.045, 0.043)
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.19, 0.28, 0.30)
    env.ambient_light_energy = 0.48
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_light_color = Color(0.055, 0.105, 0.105)
    env.fog_density = 0.012
    env.fog_sky_affect = 0.65
    world_env.environment = env
    add_child(world_env)
    var moon := DirectionalLight3D.new()
    moon.rotation_degrees = Vector3(-48, -32, 0)
    moon.light_color = Color(0.48, 0.65, 0.72)
    moon.light_energy = 0.52
    moon.shadow_enabled = true
    add_child(moon)

    _box("Island ground", Vector3(0, -0.55, 0), Vector3(144, 1, 144), _textured_mat(Color(0.8, 0.9, 0.8), 0.95, "res://assets/ground_grunge.png"), true)
    _box("Central path", Vector3(0, -0.035, 0), Vector3(8, 0.12, 132), _mat(Color(0.13, 0.16, 0.14), 0.92), true)
    _box("Cross path", Vector3(0, 0.0, -4), Vector3(124, 0.14, 7), _mat(Color(0.12, 0.15, 0.14), 0.92), true)
    _build_station()
    _build_tower()
    _build_tunnel()
    _build_forest()
    _build_ruins()
    _build_lights()
    _build_exit_gate()

func _build_station() -> void:
    var concrete := _textured_mat(Color(0.72, 0.78, 0.74), 0.88, "res://assets/concrete_grunge.png")
    var dark := _mat(Color(0.035, 0.055, 0.058), 0.75)
    _box("Station floor", Vector3(-36, 0.08, -26), Vector3(17, 0.35, 14), concrete, true)
    _box("Station back wall", Vector3(-36, 3.2, -33), Vector3(17, 6.2, 0.5), concrete, true)
    _box("Station left wall", Vector3(-44.2, 3.2, -26), Vector3(0.5, 6.2, 14), concrete, true)
    _box("Station right wall", Vector3(-27.8, 3.2, -26), Vector3(0.5, 6.2, 14), concrete, true)
    _box("Station roof", Vector3(-36, 6.35, -26), Vector3(17, 0.45, 14), dark, true)
    _box("Control console", Vector3(-36, 1.15, -30.3), Vector3(6, 1.5, 1.1), dark, true)
    _box("Console screen", Vector3(-36, 2.05, -30.0), Vector3(3.2, 0.9, 0.08), _emissive(Color(0.08, 0.55, 0.52), 1.3), false)
    _text_marker("NORTH RESEARCH STATION", Vector3(-36, 4.4, -32.68), 2.0)

func _build_tower() -> void:
    var metal := _mat(Color(0.12, 0.17, 0.18), 0.48, 0.1)
    for i in range(4):
        var a := TAU * float(i) / 4.0
        var x := 48.0 + cos(a) * 2.0
        var z := -58.0 + sin(a) * 2.0
        _cylinder("Tower leg", Vector3(x, 9.0, z), 0.16, 18.0, metal, true)
    for y in [2.0, 6.0, 10.0, 14.0, 17.5]:
        _box("Tower brace X", Vector3(48, y, -58), Vector3(4.5, 0.13, 0.13), metal, true)
        _box("Tower brace Z", Vector3(48, y, -58), Vector3(0.13, 0.13, 4.5), metal, true)
    _cylinder("Antenna mast", Vector3(48, 20.0, -58), 0.12, 5.0, metal, true)
    _sphere("Beacon", Vector3(48, 22.7, -58), 0.48, _emissive(Color(0.92, 0.18, 0.09), 2.2), false)
    var beacon_light := OmniLight3D.new()
    beacon_light.position = Vector3(48, 22.5, -58)
    beacon_light.light_color = Color(1.0, 0.12, 0.07)
    beacon_light.light_energy = 1.5
    beacon_light.omni_range = 15
    add_child(beacon_light)
    _box("Tower platform", Vector3(48, 0.7, -58), Vector3(10, 0.5, 10), metal, true)

func _build_tunnel() -> void:
    var rock := _mat(Color(0.075, 0.095, 0.09), 1.0)
    _box("Tunnel floor", Vector3(4, -0.02, 34), Vector3(11, 0.4, 25), rock, true)
    for z in range(23, 47, 4):
        _box("Tunnel left wall", Vector3(-1.7, 2.0, z), Vector3(0.6, 4.5, 4.2), rock, true)
        _box("Tunnel right wall", Vector3(9.7, 2.0, z), Vector3(0.6, 4.5, 4.2), rock, true)
        _box("Tunnel ceiling", Vector3(4, 4.2, z), Vector3(11, 0.6, 4.2), rock, true)
    for z in [27, 38, 45]:
        var lamp := OmniLight3D.new()
        lamp.position = Vector3(4, 3.55, z)
        lamp.light_color = Color(0.15, 0.62, 0.55)
        lamp.light_energy = 0.8
        lamp.omni_range = 7
        add_child(lamp)
        _box("Tunnel strip", Vector3(4, 3.78, z), Vector3(1.2, 0.08, 0.3), _emissive(Color(0.12, 0.8, 0.68), 1.2), false)

func _build_forest() -> void:
    var bark := _textured_mat(Color(0.9, 0.78, 0.68), 1.0, "res://assets/bark_grunge.png")
    var leaves := _mat(Color(0.035, 0.12, 0.085), 1.0)
    for i in range(58):
        var x := rng.randf_range(-67, 67)
        var z := rng.randf_range(-67, 67)
        if abs(x) < 7 or abs(z) < 5 or Vector2(x + 36, z + 26).length() < 13 or Vector2(x - 48, z + 58).length() < 8:
            continue
        var height := rng.randf_range(4.5, 9.5)
        _cylinder("Pine trunk", Vector3(x, height * 0.42, z), rng.randf_range(0.18, 0.34), height * 0.85, bark, true)
        for layer in range(3):
            _cone("Pine canopy", Vector3(x, height * (0.62 + layer * 0.18), z), rng.randf_range(1.5, 2.4) * (1.0 - layer * 0.18), height * 0.42, leaves, false)
    # Fallen logs and boulders make hand-push traversal routes.
    for i in range(12):
        var p := Vector3(rng.randf_range(-58, 58), 0.55, rng.randf_range(-58, 58))
        _box("Fallen log", p, Vector3(rng.randf_range(2.5, 5.0), 0.55, 0.7), bark, true, Vector3(0, rng.randf_range(-1.2, 1.2), rng.randf_range(-0.15, 0.15)))

func _build_ruins() -> void:
    var stone := _textured_mat(Color(0.75, 0.82, 0.77), 0.96, "res://assets/rock_grunge.png")
    for i in range(7):
        var x := -42.0 + i * 4.0
        _box("Ruined wall", Vector3(x, 1.5, 35), Vector3(2.7, rng.randf_range(1.4, 3.4), 0.65), stone, true, Vector3(0, rng.randf_range(-0.12, 0.12), 0))
    for i in range(9):
        var p := Vector3(rng.randf_range(-48, 48), rng.randf_range(0.6, 1.4), rng.randf_range(-48, 48))
        _sphere("Mossy boulder", p, rng.randf_range(0.7, 1.8), stone, true)

func _build_lights() -> void:
    for p in [Vector3(-36, 4.8, -26), Vector3(0, 4.0, -4), Vector3(48, 3.0, -58), Vector3(4, 3.0, 34)]:
        var lamp := OmniLight3D.new()
        lamp.position = p
        lamp.light_color = Color(0.18, 0.68, 0.59)
        lamp.light_energy = 0.75
        lamp.omni_range = 12
        add_child(lamp)

func _build_exit_gate() -> void:
    var metal := _mat(Color(0.11, 0.15, 0.16), 0.4)
    _box("Exit left post", Vector3(3.5, 2.5, -70), Vector3(0.6, 5, 0.7), metal, true)
    _box("Exit right post", Vector3(10.5, 2.5, -70), Vector3(0.6, 5, 0.7), metal, true)
    _box("Exit top", Vector3(7, 5, -70), Vector3(7.6, 0.6, 0.7), metal, true)
    _box("Exit barrier", Vector3(7, 1.8, -70), Vector3(6.7, 3.4, 0.35), _emissive(Color(0.18, 0.31, 0.28), 0.4), false)
    _text_marker("EVACUATION // LOCKED", Vector3(7, 4.1, -69.55), 1.8)

func _build_audio_and_flashlight() -> void:
    flashlight = SpotLight3D.new()
    flashlight.name = "Headlamp"
    flashlight.position = Vector3(0.05, -0.04, -0.12)
    flashlight.rotation_degrees = Vector3(-3, 0, 0)
    flashlight.light_color = Color(0.72, 0.9, 0.86)
    flashlight.light_energy = 2.1
    flashlight.spot_range = 27.0
    flashlight.spot_angle = 38.0
    flashlight.shadow_enabled = false
    camera.add_child(flashlight)
    ambience = AudioStreamPlayer.new()
    ambience.name = "IslandAmbience"
    ambience.stream = load("res://assets/island_ambience.wav")
    ambience.volume_db = -13.0
    ambience.autoplay = true
    ambience.finished.connect(func(): ambience.play())
    add_child(ambience)

func _spawn_relays() -> void:
    var names := ["STATION RELAY", "TOWER RELAY", "TUNNEL RELAY"]
    for i in range(relay_positions.size()):
        var area := Area3D.new()
        area.name = "Relay_%d" % i
        area.position = relay_positions[i]
        area.collision_layer = 0
        area.collision_mask = 2
        var shape := CollisionShape3D.new()
        var sphere := SphereShape3D.new()
        sphere.radius = 1.4
        shape.shape = sphere
        area.add_child(shape)
        var pedestal := MeshInstance3D.new()
        var cyl := CylinderMesh.new()
        cyl.top_radius = 0.42
        cyl.bottom_radius = 0.62
        cyl.height = 1.1
        pedestal.mesh = cyl
        pedestal.material_override = _mat(Color(0.13, 0.18, 0.19), 0.42)
        pedestal.position.y = -0.45
        area.add_child(pedestal)
        var core := MeshInstance3D.new()
        var crystal := SphereMesh.new()
        crystal.radius = 0.36
        crystal.height = 0.85
        core.mesh = crystal
        core.material_override = _emissive(Color(0.12, 0.92, 0.72), 2.2)
        core.position.y = 0.65
        area.add_child(core)
        var light := OmniLight3D.new()
        light.position.y = 0.8
        light.light_color = Color(0.08, 0.9, 0.68)
        light.light_energy = 1.0
        light.omni_range = 4.5
        area.add_child(light)
        add_child(area)
        relays.append(area)
        var label := Label3D.new()
        label.text = names[i]
        label.font_size = 48
        label.pixel_size = 0.006
        label.position = Vector3(0, 1.8, 0)
        label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        area.add_child(label)

func _spawn_monster() -> void:
    monster = CharacterBody3D.new()
    monster.name = "The Listener"
    monster.position = monster_home
    var shape := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.62
    capsule.height = 2.5
    shape.shape = capsule
    shape.position.y = 1.25
    monster.add_child(shape)
    var body := MeshInstance3D.new()
    var body_mesh := CapsuleMesh.new()
    body_mesh.radius = 0.58
    body_mesh.height = 2.45
    body.mesh = body_mesh
    body.material_override = _mat(Color(0.018, 0.028, 0.03), 0.9)
    body.position.y = 1.25
    monster.add_child(body)
    for side in [-1.0, 1.0]:
        var eye := MeshInstance3D.new()
        var eye_mesh := SphereMesh.new()
        eye_mesh.radius = 0.075
        eye_mesh.height = 0.12
        eye.mesh = eye_mesh
        eye.material_override = _emissive(Color(0.78, 0.29, 0.09), 0.55)
        eye.position = Vector3(side * 0.19, 1.78, -0.51)
        monster.add_child(eye)
    var point_light := OmniLight3D.new()
    point_light.position = Vector3(0, 1.8, -0.7)
    point_light.light_color = Color(0.65, 0.12, 0.05)
    point_light.light_energy = 0.18
    point_light.omni_range = 2.0
    monster.add_child(point_light)
    add_child(monster)

func _build_hud() -> void:
    var layer := CanvasLayer.new()
    layer.name = "HUD"
    add_child(layer)
    hud = Label.new()
    hud.position = Vector2(28, 24)
    hud.add_theme_font_size_override("font_size", 24)
    hud.add_theme_color_override("font_color", Color(0.7, 0.95, 0.88))
    layer.add_child(hud)
    objective_label = Label.new()
    objective_label.position = Vector2(28, 60)
    objective_label.add_theme_font_size_override("font_size", 18)
    objective_label.add_theme_color_override("font_color", Color(0.8, 0.87, 0.83))
    layer.add_child(objective_label)
    message_label = Label.new()
    message_label.position = Vector2(0, 115)
    message_label.size = Vector2(1280, 60)
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.add_theme_font_size_override("font_size", 30)
    message_label.add_theme_color_override("font_color", Color(0.75, 1.0, 0.91))
    layer.add_child(message_label)
    _update_hud()

func _physics_process(delta: float) -> void:
    if game_over:
        return
    _update_hand_locomotion(delta)
    _update_snap_turn()
    _update_flashlight(delta)
    _update_monster(delta)
    _check_relays()
    if xr_active:
        var head := camera.global_position
        if head.y < -3.0:
            global_position = Vector3(0, 0.3, 0)
            velocity = Vector3.ZERO
    else:
        _desktop_preview(delta)
    _update_hud()

func _update_hand_locomotion(delta: float) -> void:
    if not xr_active:
        return
    var lp := left_hand.position
    var rp := right_hand.position
    if not have_hand_history:
        previous_left = lp
        previous_right = rp
        have_hand_history = true
        return
    var ldelta := lp - previous_left
    var rdelta := rp - previous_right
    if _hand_touches_world(left_hand.global_position):
        velocity -= origin.global_basis * ldelta * PUSH_GAIN
    if _hand_touches_world(right_hand.global_position):
        velocity -= origin.global_basis * rdelta * PUSH_GAIN
    previous_left = lp
    previous_right = rp
    var horizontal := Vector3(velocity.x, 0, velocity.z)
    if horizontal.length() > MAX_SPEED:
        horizontal = horizontal.normalized() * MAX_SPEED
        velocity.x = horizontal.x
        velocity.z = horizontal.z
    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    else:
        velocity.y = minf(velocity.y, 0.0)
    move_and_slide()

func _hand_touches_world(hand_pos: Vector3) -> bool:
    var sphere := SphereShape3D.new()
    sphere.radius = HAND_RADIUS
    var query := PhysicsShapeQueryParameters3D.new()
    query.shape = sphere
    query.transform = Transform3D(Basis.IDENTITY, hand_pos)
    query.collision_mask = WORLD_MASK
    query.exclude = [get_rid()]
    return get_world_3d().direct_space_state.intersect_shape(query, 1).size() > 0

func _update_snap_turn() -> void:
    if not xr_active:
        return
    var stick := right_hand.get_vector2("primary")
    if absf(stick.x) < 0.65:
        snap_ready = true
    elif snap_ready:
        origin.rotate_y(-signf(stick.x) * SNAP_RADIANS)
        snap_ready = false

func _update_flashlight(delta: float) -> void:
    var pressed := xr_active and right_hand.is_button_pressed("trigger_click")
    if pressed and not trigger_was_pressed:
        flashlight_on = not flashlight_on
    trigger_was_pressed = pressed
    if flashlight:
        flashlight.visible = flashlight_on and battery > 0.0
    battery = maxf(0.0, battery - (0.045 * delta if flashlight_on else 0.0))
    if battery <= 0.0:
        flashlight_on = false
    if flashlight and battery <= 0.0:
        flashlight.visible = false

func _update_monster(delta: float) -> void:
    if monster == null:
        return
    var target := global_position
    target.y = monster.global_position.y
    var distance := monster.global_position.distance_to(target)
    if distance < 28.0:
        var direction := (target - monster.global_position).normalized()
        monster.velocity.x = direction.x * monster_speed
        monster.velocity.z = direction.z * monster_speed
        monster.move_and_slide()
        monster.look_at(Vector3(target.x, monster.global_position.y, target.z))
    else:
        monster.velocity = Vector3.ZERO
    if distance < 1.55:
        _show_message("IT HEARD YOU. RUN.", 2.0)
        global_position = Vector3(0, 0.25, 0)
        velocity = Vector3.ZERO
        monster.global_position = monster_home
        battery = maxf(35.0, battery - 20.0)

func _check_relays() -> void:
    for relay in relays:
        if not is_instance_valid(relay) or relay.is_queued_for_deletion():
            continue
        if global_position.distance_to(relay.global_position) < 1.55:
            relay.queue_free()
            cores_found += 1
            _show_message("RELAY RESTORED  //  %d / 3" % cores_found, 3.0)
            if cores_found == 3:
                monster_speed = 4.1
                _show_message("EXIT GATE UNLOCKED — GET OUT", 5.0)
                var barrier := get_node_or_null("Exit barrier")
                if barrier:
                    barrier.queue_free()
    if cores_found == 3 and global_position.distance_to(Vector3(7, 0, -68)) < 3.5:
        game_over = true
        _show_message("YOU ESCAPED // SHIFT COMPLETE", 30.0)

func _desktop_preview(delta: float) -> void:
    var input := Vector3.ZERO
    input.x = Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left")
    input.z = Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up")
    if input.length() > 0.0:
        input = input.normalized()
        var forward := -global_transform.basis.z
        var right := global_transform.basis.x
        velocity.x = (right * input.x + forward * input.z).x * 4.0
        velocity.z = (right * input.x + forward * input.z).z * 4.0
    else:
        velocity.x = move_toward(velocity.x, 0.0, 7.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 7.0 * delta)
    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    else:
        velocity.y = -0.1
    move_and_slide()
    if Input.is_action_just_pressed("ui_accept"):
        _show_message("DESKTOP PREVIEW: WASD / ARROWS", 2.0)

func _update_hud() -> void:
    if hud:
        hud.text = "PRIMATE // AFTER DARK     BATTERY %03d%%" % int(battery)
    if objective_label:
        objective_label.text = "RESTORE RELAYS: %d / 3     |     SNAP TURN: 35°     |     SPEED CAP: %.1f" % [cores_found, MAX_SPEED]

func _show_message(text_value: String, duration: float) -> void:
    if message_label:
        message_label.text = text_value
        var timer := get_tree().create_timer(duration)
        timer.timeout.connect(func():
            if is_instance_valid(message_label) and message_label.text == text_value:
                message_label.text = ""
        )

func _box(label_text: String, pos: Vector3, size: Vector3, material: Material, collision: bool, rot: Vector3 = Vector3.ZERO) -> Node3D:
    var root := Node3D.new()
    root.name = label_text
    root.position = pos
    root.rotation = rot
    var mesh_node := MeshInstance3D.new()
    var box_mesh := BoxMesh.new()
    box_mesh.size = size
    mesh_node.mesh = box_mesh
    mesh_node.material_override = material
    root.add_child(mesh_node)
    if collision:
        var body := StaticBody3D.new()
        var shape := CollisionShape3D.new()
        var box_shape := BoxShape3D.new()
        box_shape.size = size
        shape.shape = box_shape
        body.add_child(shape)
        root.add_child(body)
    add_child(root)
    return root

func _cylinder(label_text: String, pos: Vector3, radius: float, height: float, material: Material, collision: bool) -> void:
    var root := Node3D.new()
    root.name = label_text
    root.position = pos
    var mesh_node := MeshInstance3D.new()
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius
    mesh.height = height
    mesh.radial_segments = 8
    mesh_node.mesh = mesh
    mesh_node.material_override = material
    root.add_child(mesh_node)
    if collision:
        var body := StaticBody3D.new()
        var shape := CollisionShape3D.new()
        var cshape := CylinderShape3D.new()
        cshape.radius = radius
        cshape.height = height
        shape.shape = cshape
        body.add_child(shape)
        root.add_child(body)
    add_child(root)

func _cone(label_text: String, pos: Vector3, radius: float, height: float, material: Material, collision: bool) -> void:
    var mesh_node := MeshInstance3D.new()
    mesh_node.name = label_text
    var mesh := CylinderMesh.new()
    mesh.top_radius = 0.0
    mesh.bottom_radius = radius
    mesh.height = height
    mesh.radial_segments = 7
    mesh_node.mesh = mesh
    mesh_node.position = pos
    mesh_node.material_override = material
    add_child(mesh_node)

func _sphere(label_text: String, pos: Vector3, radius: float, material: Material, collision: bool) -> void:
    var mesh_node := MeshInstance3D.new()
    mesh_node.name = label_text
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh_node.mesh = mesh
    mesh_node.position = pos
    mesh_node.material_override = material
    add_child(mesh_node)
    if collision:
        var body := StaticBody3D.new()
        var shape := CollisionShape3D.new()
        var s := SphereShape3D.new()
        s.radius = radius
        shape.shape = s
        body.add_child(shape)
        body.position = pos
        add_child(body)

func _text_marker(text_value: String, pos: Vector3, scale_value: float) -> void:
    var label := Label3D.new()
    label.text = text_value
    label.position = pos
    label.font_size = 48
    label.pixel_size = 0.006 * scale_value
    label.modulate = Color(0.5, 0.82, 0.76)
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    add_child(label)

func _mat(color: Color, roughness: float, metallic: float = 0.0) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.roughness = roughness
    material.metallic = metallic
    return material

func _textured_mat(tint: Color, roughness: float, texture_path: String) -> StandardMaterial3D:
    var material := _mat(tint, roughness, 0.0)
    var texture := load(texture_path) as Texture2D
    if texture:
        material.albedo_texture = texture
        material.uv1_scale = Vector3(3.0, 3.0, 3.0)
    return material

func _emissive(color: Color, energy: float) -> StandardMaterial3D:
    var material := _mat(color, 0.35, 0.1)
    material.emission_enabled = true
    material.emission = color
    material.emission_energy_multiplier = energy
    return material
