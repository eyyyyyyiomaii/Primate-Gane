extends Node3D
@export var snap_turn_degrees := 35.0
@export var move_speed := 4.5
var xr_on := false
var xr_origin: XROrigin3D
var player: CharacterBody3D
var desktop_camera: Camera3D
var snap_timer := 0.0
var info: Label3D
var relays := 0
var objective_text := "Find the three power relays"
var credits := 0
var companion_owned := false
var companion: Node3D
var active_monster: Node3D
var shop_position := Vector3(3.0, 0.0, -4.0)
var right_hand: XRController3D
var trigger_was_down := false
var companion_busy := false

func _ready():
    build_environment()
    build_level()
    build_player()
    build_hud()
    setup_xr()
    setup_shop_and_companion()

func build_environment():
    var we=WorldEnvironment.new()
    var e=Environment.new()
    e.background_mode=Environment.BG_COLOR
    e.background_color=Color(0.008,0.012,0.016)
    e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color=Color(0.34,0.39,0.42)
    e.ambient_light_energy=0.55
    we.environment=e
    add_child(we)
    var l=DirectionalLight3D.new()
    l.rotation_degrees=Vector3(-48,-25,0)
    l.light_energy=0.7
    add_child(l)

func build_player():
    player=CharacterBody3D.new()
    player.position=Vector3(0,0.1,7)
    add_child(player)
    var cs=CollisionShape3D.new()
    var cap=CapsuleShape3D.new()
    cap.radius=0.24
    cap.height=1.35
    cs.shape=cap
    cs.position.y=0.75
    player.add_child(cs)
    xr_origin=XROrigin3D.new()
    player.add_child(xr_origin)
    var cam=XRCamera3D.new()
    cam.position.y=1.6
    xr_origin.add_child(cam)
    for side in ["left","right"]:
        var hand=XRController3D.new()
        hand.tracker=StringName(side+"_hand")
        hand.pose=&"default"
        hand.name=side+"Hand"
        xr_origin.add_child(hand)
        if side == "right": right_hand = hand
    desktop_camera=Camera3D.new()
    desktop_camera.position=Vector3(0,2.1,11)
    desktop_camera.rotation_degrees=Vector3(-9,0,0)
    desktop_camera.current=true
    add_child(desktop_camera)

func setup_xr():
    var iface=XRServer.find_interface("OpenXR")
    if iface and (iface.is_initialized() or iface.initialize()):
        xr_on=true
        get_viewport().use_xr=true
        desktop_camera.current=false
        info.text="OPENXR ACTIVE"
    else:
        info.text="DESKTOP PREVIEW — enable OpenXR for Quest"

func build_hud():
    info=Label3D.new()
    info.text="PRIMATE"
    info.font_size=38
    info.position=Vector3(0,3,-4)
    info.billboard=BaseMaterial3D.BILLBOARD_ENABLED
    info.modulate=Color(1,0.63,0.32)
    add_child(info)

func _physics_process(delta):
    if not player: return
    if not player.is_on_floor(): player.velocity.y-=9.8*delta
    else: player.velocity.y=maxf(player.velocity.y,0)
    if snap_timer>0: snap_timer-=delta
    if xr_on and snap_timer<=0:
        if Input.is_action_just_pressed("ui_left"):
            xr_origin.rotate_y(deg_to_rad(snap_turn_degrees)); snap_timer=0.25
        elif Input.is_action_just_pressed("ui_right"):
            xr_origin.rotate_y(deg_to_rad(-snap_turn_degrees)); snap_timer=0.25
    player.move_and_slide()
    update_companion(delta)
    update_pursuer(delta)
    handle_point_command()

func add_box(n,p,s,c):
    var m=MeshInstance3D.new()
    var bm=BoxMesh.new(); bm.size=s; m.mesh=bm; m.position=p
    var mat=StandardMaterial3D.new(); mat.albedo_color=c; mat.roughness=0.88
    m.material_override=mat; add_child(m)
    var b=StaticBody3D.new(); b.position=p
    var cs=CollisionShape3D.new(); var sh=BoxShape3D.new(); sh.size=s; cs.shape=sh
    b.add_child(cs); add_child(b)

func add_cylinder(n,p,r,h,c):
    var m=MeshInstance3D.new()
    var cm=CylinderMesh.new(); cm.top_radius=r; cm.bottom_radius=r; cm.height=h
    m.mesh=cm; m.position=p
    var mat=StandardMaterial3D.new(); mat.albedo_color=c; m.material_override=mat
    add_child(m)

func add_tree(p):
    add_cylinder("Trunk",p+Vector3(0,1.3,0),0.22,2.6,Color(0.16,0.09,0.045))
    var crown=MeshInstance3D.new()
    var sm=SphereMesh.new(); sm.radius=1.15; sm.height=2.3; crown.mesh=sm
    crown.position=p+Vector3(0,3,0)
    var mat=StandardMaterial3D.new(); mat.albedo_color=Color(0.045,0.16,0.085); mat.roughness=1
    crown.material_override=mat; add_child(crown)

func relay(p):
    var area=Area3D.new()
    area.position=p
    var cs=CollisionShape3D.new(); var sh=SphereShape3D.new(); sh.radius=1.0; cs.shape=sh
    area.add_child(cs); add_child(area)
    var visual=MeshInstance3D.new()
    var mesh=BoxMesh.new(); mesh.size=Vector3(0.5,0.8,0.35); visual.mesh=mesh
    var mat=StandardMaterial3D.new(); mat.albedo_color=Color(0.1,0.65,0.9); mat.emission_enabled=true
    mat.emission=Color(0.05,0.35,0.8); visual.material_override=mat
    area.add_child(visual)
    area.body_entered.connect(func(body):
        if body==player and not area.is_queued_for_deletion():
            relays+=1
            credits+=1
            area.queue_free()
            info.text="Relay %d/3 • Scrap %d — %s" % [relays, credits, "Exit powered!" if relays==3 else "Find the next relay"]
    )

func monster(p):
    var enemy=Node3D.new()
    enemy.name="RedHollower"
    enemy.position=p
    enemy.add_to_group("pursuer")
    add_child(enemy)
    active_monster=enemy
    var body=MeshInstance3D.new()
    var sm=SphereMesh.new(); sm.radius=0.72; sm.height=1.55; body.mesh=sm
    var mat=StandardMaterial3D.new(); mat.albedo_color=Color(0.48,0.025,0.018)
    mat.emission_enabled=true; mat.emission=Color(0.28,0.012,0.004); mat.roughness=0.7
    body.material_override=mat; body.position.y=0.95; enemy.add_child(body)
    # Broad red arms and a pale mask echo the reference without graphic detail.
    for side in [-1.0,1.0]:
        var arm=MeshInstance3D.new(); var am=CapsuleMesh.new(); am.radius=0.17; am.height=1.15
        arm.mesh=am; arm.position=Vector3(side*0.72,0.82,-0.02); arm.rotation.z=side*0.75
        arm.material_override=mat; enemy.add_child(arm)
    var face=MeshInstance3D.new(); var fm=SphereMesh.new(); fm.radius=0.39; fm.height=0.5
    face.mesh=fm; face.position=Vector3(0,1.12,-0.57)
    var fmatter=StandardMaterial3D.new(); fmatter.albedo_color=Color(0.72,0.67,0.58); face.material_override=fmatter
    enemy.add_child(face)
    for x in [-0.16,0.16]:
        var eye=MeshInstance3D.new(); var em=SphereMesh.new(); em.radius=0.07; eye.mesh=em
        var mm=StandardMaterial3D.new(); mm.albedo_color=Color(0.015,0.008,0.008)
        eye.material_override=mm; eye.position=Vector3(x,1.18,-0.91); enemy.add_child(eye)
    var phrase=Label3D.new()
    phrase.text="БУУУРМАЛДА... БУРМАЛДА..."
    phrase.font_size=24; phrase.position=Vector3(0,2.25,0)
    phrase.billboard=BaseMaterial3D.BILLBOARD_ENABLED
    phrase.modulate=Color(1.0,0.34,0.22); enemy.add_child(phrase)
    enemy.set_meta("phrase_timer",0.0)
    enemy.set_meta("bob_time",0.0)
    enemy.set_meta("base_y",p.y)

func setup_shop_and_companion():
    # Small in-world kiosk; the companion is previewed above it.
    add_box("CompanionShop",shop_position+Vector3(0,0.65,0),Vector3(1.8,1.3,0.7),Color(0.12,0.16,0.2))
    var sign=Label3D.new()
    sign.text="SCRAP SHOP\nFLOATING BUDDY — 2 SCRAP\nStand close + press E / trigger"
    sign.font_size=22; sign.position=shop_position+Vector3(0,2.0,-0.42)
    sign.billboard=BaseMaterial3D.BILLBOARD_ENABLED
    sign.modulate=Color(0.5,0.9,1.0); add_child(sign)
    var preview=create_companion_model()
    preview.position=shop_position+Vector3(0,1.45,-0.8)
    add_child(preview)

func create_companion_model() -> Node3D:
    var buddy=Node3D.new()
    var shell=MeshInstance3D.new(); var sphere=SphereMesh.new()
    sphere.radius=0.24; sphere.height=0.48; shell.mesh=sphere
    var white=StandardMaterial3D.new(); white.albedo_color=Color(0.82,0.86,0.88)
    white.metallic=0.25; white.roughness=0.35; shell.material_override=white
    buddy.add_child(shell)
    var core=MeshInstance3D.new(); var orb=SphereMesh.new(); orb.radius=0.12; orb.height=0.24
    core.mesh=orb; core.position=Vector3(0,0,-0.2)
    var orange=StandardMaterial3D.new(); orange.albedo_color=Color(1.0,0.28,0.035)
    orange.emission_enabled=true; orange.emission=Color(1.0,0.12,0.01); core.material_override=orange
    buddy.add_child(core)
    for x in [-0.09,0.09]:
        var eye=MeshInstance3D.new(); var em=SphereMesh.new(); em.radius=0.035; eye.mesh=em
        eye.position=Vector3(x,0.04,-0.22)
        var dark=StandardMaterial3D.new(); dark.albedo_color=Color(0.02,0.025,0.03)
        eye.material_override=dark; buddy.add_child(eye)
    return buddy

func update_companion(delta):
    if companion_owned and is_instance_valid(companion) and not companion_busy:
        var desired=player.global_position+Vector3(0.65,1.7,0.55)
        companion.global_position=companion.global_position.lerp(desired,clampf(delta*3.5,0.0,1.0))
        companion.rotate_y(delta*1.5)

func handle_point_command():
    var pressed=false
    var ray_origin:Vector3
    var ray_dir:Vector3
    if xr_on and is_instance_valid(right_hand):
        pressed=right_hand.is_button_pressed("trigger") and not trigger_was_down
        ray_origin=right_hand.global_position
        ray_dir=-right_hand.global_transform.basis.z
        trigger_was_down=right_hand.is_button_pressed("trigger")
    else:
        pressed=Input.is_action_just_pressed("ui_accept")
        ray_origin=desktop_camera.global_position
        ray_dir=-desktop_camera.global_transform.basis.z
    if not pressed: return
    if player.global_position.distance_to(shop_position)<3.0 and not companion_owned:
        if credits>=2:
            credits-=2; companion_owned=true
            companion=create_companion_model(); add_child(companion)
            companion.global_position=player.global_position+Vector3(0,1.7,0)
            info.text="COMPANION UNLOCKED • point at the monster and press trigger / Enter"
        else:
            info.text="SCRAP SHOP • need 2 scrap (collect relays)"
        return
    if not companion_owned or companion_busy or not is_instance_valid(active_monster): return
    var to_enemy=active_monster.global_position+Vector3(0,0.9,0)-ray_origin
    var distance=to_enemy.length()
    if distance<28.0 and ray_dir.normalized().dot(to_enemy.normalized())>0.94:
        launch_companion()

func launch_companion():
    if not is_instance_valid(companion) or companion_busy: return
    companion_busy=true
    var target=active_monster.global_position+Vector3(0,0.9,0)
    var tween=create_tween()
    tween.tween_property(companion,"global_position",target,0.65).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    tween.finished.connect(func():
        if is_instance_valid(companion):
            make_companion_burst(companion.global_position)
            companion.queue_free()
        companion=null
        companion_owned=false
        companion_busy=false
        info.text="BUDDY USED! Visit the shop to buy another"
    )

func make_companion_burst(at:Vector3):
    for i in range(10):
        var spark=MeshInstance3D.new(); var mesh=SphereMesh.new()
        mesh.radius=0.07; mesh.height=0.14; spark.mesh=mesh
        var mat=StandardMaterial3D.new(); mat.albedo_color=Color(1.0,0.35,0.06)
        mat.emission_enabled=true; mat.emission=Color(1.0,0.18,0.015); spark.material_override=mat
        spark.global_position=at; add_child(spark)
        var angle=TAU*float(i)/10.0
        var dest=at+Vector3(cos(angle),sin(angle*2.0)*0.7,sin(angle))*1.1
        var tw=create_tween(); tw.tween_property(spark,"global_position",dest,0.35)
        tw.parallel().tween_property(spark,"scale",Vector3.ZERO,0.35)
        tw.finished.connect(spark.queue_free)


func update_pursuer(delta):
    if not is_instance_valid(active_monster) or not is_instance_valid(player): return
    var enemy=active_monster
    var target=player.global_position+Vector3(0,1.0,0)
    var distance=enemy.global_position.distance_to(target)
    if distance<25.0:
        enemy.global_position=enemy.global_position.move_toward(target,delta*(1.15 if distance>5.0 else 0.45))
    var bob=float(enemy.get_meta("bob_time",0.0))+delta*2.2
    enemy.set_meta("bob_time",bob)
    enemy.global_position.y=float(enemy.get_meta("base_y",1.0))+sin(bob)*0.18
    var timer=float(enemy.get_meta("phrase_timer",0.0))-delta
    if timer<=0.0:
        timer=5.2
        # Android/Quest may provide a system TTS voice; the floating caption remains as fallback.
        var voices=DisplayServer.tts_get_voices()
        if voices.size()>0:
            var voice_id=str(voices[0].get("id", ""))
            DisplayServer.tts_speak("Бурмалда. Бурмалда. Бурмалда.", voice_id, 1.0, 0.72, 0.78, 42)
    enemy.set_meta("phrase_timer",timer)

func build_level():
    # Forest map preserved: forest, research station, radio tower, ruins and tunnel.
    add_box("ForestFloor",Vector3(0,-0.35,0),Vector3(70,0.7,70),Color(0.10,0.16,0.095))
    for x in range(-30,31,6):
        for z in range(-30,31,6):
            if abs(x)<7 and abs(z)<8: continue
            add_tree(Vector3(x,0,z))
    # Research station clearing and building
    add_box("StationFloor",Vector3(0,0.05,-5),Vector3(12,0.2,10),Color(0.22,0.22,0.20))
    add_box("StationBuilding",Vector3(0,1.5,-8),Vector3(8,3,0.35),Color(0.32,0.34,0.31))
    add_box("StationSideL",Vector3(-4,1.5,-5),Vector3(0.35,3,6),Color(0.28,0.30,0.28))
    add_box("StationSideR",Vector3(4,1.5,-5),Vector3(0.35,3,6),Color(0.28,0.30,0.28))
    # Radio tower
    for p in [Vector3(16,3,13),Vector3(16,6,13),Vector3(16,9,13)]:
        add_cylinder("RadioTower",p,0.12,3,Color(0.25,0.27,0.28))
    add_box("TowerCrossbar",Vector3(16,8,13),Vector3(4,0.16,0.16),Color(0.35,0.38,0.4))
    # Ruins
    add_box("RuinWallA",Vector3(-17,1.5,13),Vector3(7,3,0.4),Color(0.25,0.25,0.22))
    add_box("RuinWallB",Vector3(-20,1.5,16),Vector3(0.4,3,6),Color(0.25,0.25,0.22))
    add_box("RuinWallC",Vector3(-14,1.5,16),Vector3(0.4,3,6),Color(0.25,0.25,0.22))
    # Secret easter egg: a tiny one-eyed golden triangle hidden behind the ruins.
    var cipher = MeshInstance3D.new()
    var pyramid = CylinderMesh.new()
    pyramid.top_radius = 0.0
    pyramid.bottom_radius = 0.85
    pyramid.height = 1.35
    pyramid.radial_segments = 3
    cipher.mesh = pyramid
    cipher.position = Vector3(-22.5, 1.25, 19.2)
    cipher.rotation_degrees = Vector3(0, 25, 0)
    var gold = StandardMaterial3D.new()
    gold.albedo_color = Color(1.0, 0.72, 0.08)
    gold.emission_enabled = true
    gold.emission = Color(0.65, 0.35, 0.015)
    cipher.material_override = gold
    add_child(cipher)
    var eye = MeshInstance3D.new()
    var eye_mesh = SphereMesh.new()
    eye_mesh.radius = 0.19
    eye_mesh.height = 0.24
    eye.mesh = eye_mesh
    eye.position = Vector3(-22.5, 1.38, 18.72)
    var eye_mat = StandardMaterial3D.new()
    eye_mat.albedo_color = Color(0.06, 0.035, 0.01)
    eye.material_override = eye_mat
    add_child(eye)
    # Tunnel entrance and dark passage
    add_box("TunnelLeft",Vector3(0,1.5,22),Vector3(1,3,10),Color(0.12,0.12,0.13))
    add_box("TunnelRight",Vector3(4,1.5,22),Vector3(1,3,10),Color(0.12,0.12,0.13))
    add_box("TunnelRoof",Vector3(2,3,22),Vector3(5,0.5,10),Color(0.09,0.09,0.10))
    relay(Vector3(0,0.8,-3)); relay(Vector3(16,0.8,13)); relay(Vector3(-17,0.8,14))
    monster(Vector3(2,4,19))
    # Scrap shop is placed beside the research station.
    info.text="FOREST NIGHT SHIFT\nStation • Radio Tower • Ruins • Tunnel\nCollect scrap, buy a buddy, point at the red flyer!"
