# Game design notes

The supplied drawings are treated as silhouette references: oversized head, uneven crown/spikes, broad torso, elongated arms, bright but restrained eye accents. The supplied clips suggest warm industrial interiors, connected corridors, platforms, pipes, object-based VR locomotion and a stylized multiplayer-primate tone. All geometry/materials in this prototype are generated procedurally and are original placeholders.

Seven variants share the same core loop but use distinct zone names, accent colors and creature identities. The capture sequence is non-graphic: the player can break free by moving both tracked hands.
